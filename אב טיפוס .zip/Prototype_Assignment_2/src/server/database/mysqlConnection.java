package server.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import server.common.controllers.MainServerController;

public class mysqlConnection {

	private static Connection connection;

	public static boolean connectToDB() { // this method connects to a database
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			MainServerController.instance.add_Line("Driver definition succeed");
		} catch (Exception ex) {
			/* handle the error */
			MainServerController.instance.add_Line("Driver definition failed");
			return false;
		}

		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost/prototype?serverTimezone=IST", "root",
					"207063546");
			MainServerController.instance.add_Line("SQL connection succeed");
			return true;
		} catch (SQLException ex) {/* handle any errors */
			MainServerController.instance.add_Line("SQLException: " + ex.getMessage());
			MainServerController.instance.add_Line("SQLState: " + ex.getSQLState());
			MainServerController.instance.add_Line("VendorError: " + ex.getErrorCode());
			return false;
		}
	}

	public Connection getConnection() {
		return connection;
	}

	public static ResultSet executeQuary(String quary) { // this method recives a query and returns a result set
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(quary);
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static boolean updateQuary(String quary) {	//this method is for updating querying in the database
		try {
			Statement stmt = connection.createStatement();
			if (stmt.executeUpdate(quary) == 0) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
