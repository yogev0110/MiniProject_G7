package message_info;

public enum ReturnMessageType {
	UPDATE_FAILED,UPDATE_SUCCESSFUL,RETURNED_INFO,RETURNED_INFO_FAILED;
}
