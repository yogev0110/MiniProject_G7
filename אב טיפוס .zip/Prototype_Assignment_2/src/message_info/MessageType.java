package message_info;

public enum MessageType {
	REQUESTINFO,UPDATEINFO;
}
