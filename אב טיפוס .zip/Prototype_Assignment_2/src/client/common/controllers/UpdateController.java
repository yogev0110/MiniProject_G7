package client.common.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.beans.binding.StringBinding;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import message_info.Message;
import message_info.MessageType;
import server.MainServerGui;

public class UpdateController implements Initializable {

	public static UpdateController instance;
	public String original_position;

	@FXML
	private Button return_btn;

	@FXML
	private TextField eid_input;

	@FXML
	private Button search_btn;

	@FXML
	private TextField first_name;

	@FXML
	private TextField orginization;

	@FXML
	private TextField position;

	@FXML
	private TextField email;

	@FXML
	private TextField eid;

	@FXML
	private TextField last_name;

	@FXML
	private Button update_btn;

	@FXML
	private Text text_result;

	// this method will display for the user messages of the update screen
	public void display_result(String text) {
		text_result.setVisible(true);
		text_result.setText(text);
		Task<Void> sleeper = new Task<Void>() {
			@Override
			protected Void call() throws Exception {
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
				}
				return null;
			}
		};
		sleeper.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
			@Override
			public void handle(WorkerStateEvent event) {
				text_result.setVisible(false);
			}
		});
		new Thread(sleeper).start();
	}

	// this method will return us to the main screen
	@FXML
	void return_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MainClientPrototypeForm.fxml", (Node) event.getSource());
	}

	// this method will activate when we want to search a worker
	@FXML
	void search_clicked(MouseEvent event) {
		if (eid_input.getText().isEmpty()) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("FIELD NOT FILLED");
			alert.setHeaderText(null);
			alert.setContentText("Please Enter A Value");
			alert.show();
		} else {
			try {
				Integer check = new Integer(eid_input.getText());
				if (check <= 0) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("INVALID INPUT");
					alert.setHeaderText(null);
					alert.setContentText("Please Enter A Vaild Input");
					alert.show();
					return;
				}
			} catch (Exception e) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("INVALID INPUT");
				alert.setHeaderText(null);
				alert.setContentText("Please Enter A Vaild Input");
				alert.show();
				return;
			}
			String quary = "SELECT * FROM employee WHERE eid = " + eid_input.getText();
			Message message = new Message(MessageType.REQUESTINFO, new String("search_employee"), quary);
			// send the server the query
			MainClientGUI.client.handleMessageFromClientUI(message);
		}
	}

	// this method will activate when the update button is clicked
	@FXML
	void update_clicked(MouseEvent event) {
		if (position.getText().isEmpty()) {
			display_result("UPDATE FAILED");
			return;
		}
		if (original_position.equals(position.getText())) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("FIELD NOT CHANGED");
			alert.setHeaderText(null);
			alert.setContentText("Please Enter A Different Value");
			alert.show();
			return;
		}
		original_position = position.getText();
		String new_position = "\"" + position.getText() + "\"";
		String quary = "UPDATE employee SET Position = " + new_position + " WHERE eid = " + eid.getText();
		Message message = new Message(MessageType.UPDATEINFO, new String("update_employee"), quary);
		// send the server the query
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	// this is a helper method, that iserts information to the main table
	public void insertToScreen(ArrayList<ArrayList<Object>> row) {
		first_name.setText((String) row.get(0).get(0));
		last_name.setText((String) row.get(0).get(1));
		Integer number = (Integer) row.get(0).get(2);
		eid.setText(number.toString());
		email.setText((String) row.get(0).get(3));
		position.setText((String) row.get(0).get(4));
		position.setEditable(true);
		original_position = position.getText();
		orginization.setText((String) row.get(0).get(5));
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		text_result.setVisible(false);
		position.setEditable(false);
	}

	// this message is responsible to switch screens
	public void switchScenes(String fxmlFile, Node event) {

		try {
			Parent current = FXMLLoader.load(getClass().getResource(fxmlFile));
			Scene scene = new Scene(current);
			Stage window = (Stage) (event).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void clear_screen() {
		first_name.setText("");
		last_name.setText("");
		eid.setText("");
		email.setText("");
		position.setText("");
		position.setEditable(false);
		orginization.setText("");
	}

}