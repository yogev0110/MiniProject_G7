package client.common.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import client.MainClientGUI;
import client.common.UserInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import message_info.Message;
import message_info.MessageType;

public class MainClientPrototype implements Initializable {

	public static MainClientPrototype instance; // holding an instance of this controller here

	@FXML
	private Button edit_btn;

	@FXML
	private Button load_btn;

	@FXML
	private TableView<UserInfo> main_table;

	@FXML
	private TableColumn<UserInfo, String> first_nameCol;

	@FXML
	private TableColumn<UserInfo, String> last_nameCol;

	@FXML
	private TableColumn<UserInfo, Integer> eidCol;

	@FXML
	private TableColumn<UserInfo, String> emailCol;

	@FXML
	private TableColumn<UserInfo, String> positionCol;

	@FXML
	private TableColumn<UserInfo, String> orginizationCol;

	// when the edit button is clicked, this method will activate

	@FXML
	void edit_clicked(MouseEvent event) {
		if(MainClientGUI.client==null) {
			alertClientToConnectFirst();
			return;
		}
		switchScenes("/client/boundry/MainUpdatePrototypeForm.fxml", (Node) event.getSource());
	}

	// when the load button is clicked, this method will activate

	@FXML
	void load_clicked(MouseEvent event) {
		if(MainClientGUI.client==null) {
			alertClientToConnectFirst();
			return;
		}
		String quary = "SELECT * FROM employee";
		Message msg = new Message(MessageType.REQUESTINFO,new String("load_table"), quary); // sending a request for the server
		MainClientGUI.client.handleMessageFromClientUI(msg);
	}

	public void addToTable(ArrayList<ArrayList<Object>> table) { // this method recives a matrix and adds it to the
																	// table in the window
		ObservableList<UserInfo> users = FXCollections.observableArrayList();
		for (ArrayList<Object> row : table) {
			users.add(new UserInfo((String) row.get(0), (String) row.get(1), (Integer) row.get(2), (String) row.get(3),
					(String) row.get(4), (String) row.get(5)));
		}
		main_table.setItems(users);
		main_table.setVisible(true);
	}

	// this method is activate first when the client is activated.
	// responsible for creating a client instance and creating a table

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		MainClientGUI.run_Client();
		// setup columns in table
		first_nameCol.setCellValueFactory(new PropertyValueFactory<UserInfo, String>("firstName"));
		last_nameCol.setCellValueFactory(new PropertyValueFactory<UserInfo, String>("lastName"));
		eidCol.setCellValueFactory(new PropertyValueFactory<UserInfo, Integer>("eid"));
		emailCol.setCellValueFactory(new PropertyValueFactory<UserInfo, String>("email"));
		positionCol.setCellValueFactory(new PropertyValueFactory<UserInfo, String>("position"));
		orginizationCol.setCellValueFactory(new PropertyValueFactory<UserInfo, String>("orginization"));
		main_table.setVisible(false);
	}

	// this method switchs between screens
	public void switchScenes(String fxmlFile, Node event) {

		try {
			Parent current = FXMLLoader.load(getClass().getResource(fxmlFile));
			Scene scene = new Scene(current);
			Stage window = (Stage) (event).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void alertClientToConnectFirst() {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("No Server Detected!");
		alert.setHeaderText(null);
		alert.setContentText("Please Run The Server First");
		alert.show();
	}

}
