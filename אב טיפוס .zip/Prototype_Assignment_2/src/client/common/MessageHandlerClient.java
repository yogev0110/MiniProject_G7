package client.common;

import java.util.ArrayList;
import client.common.controllers.MainClientPrototype;
import client.common.controllers.UpdateController;
import message_info.*;

//this class is responsible of handling the messages recived from the server, its uses switch cases
//to know what to do

public class MessageHandlerClient {

	public static void HandleMessage(Message message) {
		switch (message.getReturnedType()) {
		case RETURNED_INFO: // requestinfo is when the server sent us info. this case
							// will handle the information recived
			switch (message.getParent_action()) {
			case "load_table":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				MainClientPrototype.instance.addToTable(table);
				break;
			case "search_employee":
				ArrayList<ArrayList<Object>> row = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateController.instance.insertToScreen(row);
				break;
			}

			break;

		case RETURNED_INFO_FAILED:
			switch (message.getParent_action()) {
			case "search_employee":
				UpdateController.instance.display_result("WORKER NOT FOUND");
				UpdateController.instance.clear_screen();
				break;
			}
			break;

		case UPDATE_FAILED: // when the server returns that the update failed, here the
							// client will handle it
			switch (message.getParent_action()) {
			case "update_employee":
				UpdateController.instance.display_result("UPDATE FAILED");
				break;
			}
			break;
		case UPDATE_SUCCESSFUL: // when the server returns that the update succeeded, here the
								// client will handle it
			switch (message.getParent_action()) {
			case "update_employee":
				UpdateController.instance.display_result("SUCCESSFULLY UPDATE");
				break;
			}
			break;
		}
	}
}
