package client;

import java.io.IOException;
import client.common.Client;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainClientGUI extends Application {

	// this class is the main class that runs the client software, is hold the
	// connection to the client side
	// and runs the fxml aspect

	final public static int DEFAULT_PORT = 5555;
	public static Client client; // an instance of the client
	private static boolean is_running = false;
	private static String client_ip = "localhost";
	private static int client_port = DEFAULT_PORT;

	@Override
	public void start(Stage primaryStage) { // runs the fxml file and displays a window
		AnchorPane pane = null;

		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/client/boundry/MainClientPrototypeForm.fxml"));
			pane = loader.load();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		Scene s = new Scene(pane);
		primaryStage.setResizable(false);
		primaryStage.setScene(s);
		primaryStage.show();
	}

	public static boolean run_Client() { // this method create a client side and saves it as a static instance

		try {
			if (!is_running) {
				client = new Client(client_ip, client_port);
				is_running = true;
				return true;
			} else
				return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
