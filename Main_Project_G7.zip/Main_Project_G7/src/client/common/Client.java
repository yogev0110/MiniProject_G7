package client.common;

import ocsf.client.*;
import java.io.*;

import javafx.beans.binding.When;
import message_info.*;

public class Client extends AbstractClient {
	
	//this class is the client side of the software

	public Client(String host, int port) throws IOException {
		super(host, port);
		openConnection();	//connect to a server here
	}
	
	//when a message is recived from the server, this method will activate

	public void handleMessageFromServer(Object msg) {		
		Message message = (Message) msg;
		MessageHandlerClient.HandleMessage(message);		//sends the message to the messageHandler
	}														//to let is handle all of the actions

	public void handleMessageFromClientUI(Object message) {	//when we want to send a message to the server
		try {												//we will activate this method
			sendToServer(message);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void quit() {									//when we want to disconnect from a sever we
		try {												//activate this method
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
