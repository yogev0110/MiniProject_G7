package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * this is an entity class for station manager reports.
 * 
 * @author henco
 * @version 1.0
 */
public class Reports {

	private SimpleStringProperty reportType, date, description;
	private Integer stationNumber, reportID;

	/**
	 * simple constractor
	 * 
	 * @param reportType    the report type in string (this name)
	 * @param date          the date the report was made
	 * @param stationNumber the station of the report
	 * @param description   the reports content
	 * @param reportID      the primary key of the report
	 */
	public Reports(String reportType, String date, Integer stationNumber, String description, Integer reportID) {

		this.description = new SimpleStringProperty(description);
		this.reportType = new SimpleStringProperty(reportType);
		this.date = new SimpleStringProperty(date);
		this.stationNumber = stationNumber;
		this.reportID = reportID;
	}

	/**
	 * returns the report id
	 * 
	 * @return report id
	 */
	public Integer getReportID() {
		return reportID;
	}

	/**
	 * returns the report type
	 * 
	 * @return report type
	 */
	public String getReportType() {
		return reportType.getValue();
	}

	/**
	 * returns the report date
	 * 
	 * @return date of report
	 */
	public String getDate() {
		return date.getValue();
	}

	/**
	 * returns the station number of the report
	 * 
	 * @return station number
	 */
	public Integer getStationNumber() {
		return stationNumber;
	}

	/**
	 * returns the content of the report
	 * 
	 * @return content
	 */
	public String getDescription() {
		return description.getValue();
	}
}
