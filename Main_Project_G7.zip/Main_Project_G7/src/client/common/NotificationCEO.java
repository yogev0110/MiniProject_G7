package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This Class is entity class For the Notification Page controller contain the
 * information for the new discounts offers that the CEO get from his Marketing
 * Manager
 * 
 * @author Meni
 * @version 0.99
 */

public class NotificationCEO {

	private SimpleStringProperty ratedate, ratetype, comment, from;
	private Float oldrate, newrate;
	private Integer ratenum;

	/**
	 * constructor - initialize the objects for CEO Notification page controller
	 * 
	 * @param ratetype - there is 4 rate type (Casual fuel,Routine monthly fuel -
	 *                 single car,Routine monthly fuel - some cars,Full monthly fuel
	 *                 - single car)
	 * @param ratedate - in this parameter we can see the date that the marketing
	 *                 manager add a new discount rate
	 * @param oldrate  - in this parameter we see the discount rate that updated in
	 *                 our system
	 * @param newrate  - in this parameter we save the new discount Percent that the
	 *                 marketing manager send to the CEO
	 * @param from     - that we know who send us the new discount offer
	 * @param comment  - the marketing manager can send a comment with his discount
	 *                 offer
	 * @param ratenum  - to every rate type there is a number id (Casual fuel -
	 *                 1,Routine monthly fuel - single car - 2,Routine monthly fuel
	 *                 - some cars - 3,Full monthly fuel - single car - 4)
	 */
	public NotificationCEO(String ratetype, String ratedate, Float oldrate, Float newrate, String from, String comment,
			Integer ratenum) {
		this.comment = new SimpleStringProperty(comment);
		this.ratedate = new SimpleStringProperty(ratedate);
		this.from = new SimpleStringProperty(from);
		this.ratetype = new SimpleStringProperty(ratetype);
		this.oldrate = oldrate;
		this.newrate = newrate;
		this.ratenum = ratenum;

	}

	/**
	 * getter for the date that the new Proposal has been created
	 * 
	 * @return ratedate -the date that the marketing manager add a new discount rate
	 */

	public String getRatedate() {
		return ratedate.getValue();
	}

	/**
	 * method that updates the value of the date
	 * 
	 * @param ratedate-the date that the marketing manager add a new discount rate
	 */

	public void setRatedate(SimpleStringProperty ratedate) {
		this.ratedate = ratedate;
	}

	/**
	 * getter for the comment
	 * 
	 * @return comment - the marketing manager can send a comment with his discount
	 *         offer
	 */

	public String getComment() {
		return comment.getValue();
	}

	/**
	 * method that updates the value of the comment
	 * 
	 * @param comment - the marketing manager can send a comment with his discount
	 *                offer
	 */
	public void setComment(SimpleStringProperty comment) {
		this.comment = comment;
	}

	/**
	 * getter for the rate type
	 * 
	 * @return ratetype - there is 4 rate type (Casual fuel,Routine monthly fuel -
	 *         single car,Routine monthly fuel - some cars,Full monthly fuel -
	 *         single car)
	 */
	public String getRatetype() {
		return ratetype.getValue();
	}

	/**
	 * method that updates the value of rate type
	 * 
	 * @param ratetype -there is 4 rate type (Casual fuel,Routine monthly fuel -
	 *                 single car,Routine monthly fuel - some cars,Full monthly fuel
	 *                 - single car)
	 */

	public void setRatetype(SimpleStringProperty ratetype) {
		this.ratetype = ratetype;
	}

	/**
	 * getter for the rate type
	 * 
	 * @return oldrate - the discount rate that updated in our system
	 * 
	 */

	public Float getOldrate() {
		return oldrate;
	}

	/**
	 * method that updates the value of oldrate
	 * 
	 * @param oldrate - the discount rate that updated in our system
	 */

	public void setOldrate(Float oldrate) {
		this.oldrate = oldrate;
	}

	/**
	 * getter for the new type
	 * 
	 * @return newrate - The new discount Percent that the marketing manager send to
	 *         the CEO
	 */

	public Float getNewrate() {
		return newrate;
	}

	/**
	 * method that updates the value of oldrate
	 * 
	 * @param newrate- The new discount Percent that the marketing manager send to
	 *                 the CEO
	 */

	public void setNewrate(Float newrate) {
		this.newrate = newrate;
	}

	/**
	 * getter for the attribute from
	 * 
	 * @return from - who send us the new discount offer
	 */

	public String getFrom() {
		return from.getValue();
	}

	/**
	 * method that updates the value from
	 * 
	 * @param from - who send us the new discount offer
	 */

	public void setFrom(SimpleStringProperty from) {
		this.from = from;
	}

	/**
	 * getter for the attribute ratenum
	 * 
	 * @return ratenum-to every rate type there is a number id (Casual fuel -
	 *         1,Routine monthly fuel - single car - 2,Routine monthly fuel - some
	 *         cars - 3,Full monthly fuel - single car - 4)
	 */

	public Integer getRatenum() {
		return ratenum;
	}

}
