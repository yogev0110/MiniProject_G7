package client.common;

import java.util.ArrayList;
import client.common.controllers.LoginController;
import client.common.controllers.MarketingAgentCustomerAddController;
import client.common.controllers.MarketingAgentCustomerEditController;
import client.common.controllers.MarketingAgentCustomerPurchasePatternController;
import client.common.controllers.MarketingAgentCustomersMainController;
import client.common.controllers.MarketingAgentMenuWelcomeController;
import client.common.controllers.MarketingAgentNotificationController;
import client.common.controllers.MarketingAgentSalesAddController;
import client.common.controllers.MarketingAgentSalesMainController;
import client.common.controllers.MarketingAgentVehicleAddController;
import client.common.controllers.MarketingAgentVehicleEditController;
import client.common.controllers.MarketingAgentVehicleMainController;
import client.common.controllers.StationManagerController;
import client.common.controllers.StationManagerNotificationController;
import client.common.controllers.StationManagerNotificationRejectController;
import client.common.controllers.StationManagerReportsController;
import client.common.controllers.StationManagerStationController;
import client.common.logic_controllers.UpdateUIController;
import message_info.*;

//this class is responsible of handling the messages recived from the server, its uses switch cases
//to know what to do

public class MessageHandlerClient {

	public static void HandleMessage(Message message) {
		switch (message.getReturnedType()) {
		case LOGIN_FAILED:
			switch (message.getParent_action()) {
			case "LoginController_login_clicked":
				LoginController.instance.return_login_failed((String) message.getContent());
				break;
			}
			break;
		case LOGIN_SUCCESSFUL:
			switch (message.getParent_action()) {
			case "LoginController_login_clicked":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				LoginController.instance.return_login_success(table);
				break;
			}
			break;
		case RETURNED_INFO:
			switch (message.getParent_action()) {
			case "StationManagerStationController_setUpFuel_request":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.initializeStationManager(table);
				break;

			default:
				break;
			}
			break;

		case RETURNED_INFO_FAILED:
			break;

		case UPDATE_FAILED:
			break;

		case UPDATE_SUCCESSFUL:
			break;

		case LOGOUT_SUCCESSFUL:
			switch (message.getParent_action()) {

			case "StationManagerController_logout_clicked":
				StationManagerController.instance.return_logout_success();
				break;

			case "StationManagerNotificationController_logout_clicked":
				StationManagerNotificationController.instance.return_logout_success();
				break;

			case "StationManagerStationController_logout_clicked":
				StationManagerStationController.instance.return_logout_success();
				break;

			case "StationManagerReportsController_logout_clicked":
				StationManagerReportsController.instance.return_logout_success();
				break;

			case "StationManagerNotificationRejectController_logout_clicked":
				StationManagerNotificationRejectController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerMainController_logout_clicked":
				MarketingAgentCustomersMainController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerAddController_logout_clicked":
				MarketingAgentCustomerAddController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleMainController_logout_clicked":
				MarketingAgentVehicleMainController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleAddController_logout_clicked":
				MarketingAgentVehicleAddController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerPurchasePatternController_logout_clicked":
				MarketingAgentCustomerPurchasePatternController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerMainContoller_logout_clicked":
				MarketingAgentCustomersMainController.instance.return_logout_success();
				break;

			case "MarketingAgentMenuWelcomeController_logout_clicked":
				MarketingAgentMenuWelcomeController.instance.return_logout_success();
				break;

			case "MarketingAgentSalesMainController_logout_clicked":
				MarketingAgentSalesMainController.instance.return_logout_success();
				break;

			case "MarketingAgentSalesAddController_logout_clicked":
				MarketingAgentSalesAddController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerEditController_logout_clicked":
				MarketingAgentCustomerEditController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleEditController_logout_clicked":
				MarketingAgentVehicleEditController.instance.return_logout_success();
				break;

			case "MarketingAgentNotificationController_logout_clicked":
				MarketingAgentNotificationController.instance.return_logout_success();
				break;

			}
			break;

		case LOGOUT_FAILED:
			switch (message.getParent_action()) {

			}
			break;
		}
	}
}
