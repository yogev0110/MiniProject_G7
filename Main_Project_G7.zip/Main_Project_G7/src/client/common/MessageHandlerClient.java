package client.common;

import java.util.ArrayList;

import client.common.controllers.CEOMenuWelcomePageController;
import client.common.controllers.CEONotificationPageController;
import client.common.controllers.CEOReportsPageController;
import client.common.controllers.CustomerMenuWelcomeController;
import client.common.controllers.CustomerNotificitionsFormController;
import client.common.controllers.CustomerOrdersHomefuelorderController;
import client.common.controllers.CustomerOrdersMainController;
import client.common.controllers.CustomerOrdersVehicleRefuelFormController;
import client.common.controllers.LoginController;
import client.common.controllers.MarketingAgentCustomerAddController;
import client.common.controllers.MarketingAgentCustomerEditController;
import client.common.controllers.MarketingAgentCustomerPurchasePatternController;
import client.common.controllers.MarketingAgentCustomersMainController;
import client.common.controllers.MarketingAgentMenuWelcomeController;
import client.common.controllers.MarketingAgentNotificationController;
import client.common.controllers.MarketingAgentSaleShowController;
import client.common.controllers.MarketingAgentSalesAddController;
import client.common.controllers.MarketingAgentSalesMainController;
import client.common.controllers.MarketingAgentVehicleAddController;
import client.common.controllers.MarketingAgentVehicleMainController;
import client.common.controllers.MarketingManagerDiscountAddController;
import client.common.controllers.MarketingManagerDiscountEditFuelPriceController;
import client.common.controllers.MarketingManagerDiscountMainController;
import client.common.controllers.MarketingManagerMenuWelcomeController;
import client.common.controllers.MarketingManagerNotificationController;
import client.common.controllers.MarketingManagerReportsController;
import client.common.controllers.MarketingManagerSaleStatisticsInformationController;
import client.common.controllers.MarketingManagerSalesAddController;
import client.common.controllers.MarketingManagerSalesMainController;
import client.common.controllers.MarketingManagerSalesShowController;
import client.common.controllers.SaleStatisticsInformationController;
import client.common.controllers.StationManagerController;
import client.common.controllers.StationManagerNotificationController;
import client.common.controllers.StationManagerNotificationRejectController;
import client.common.controllers.StationManagerReportsController;
import client.common.controllers.StationManagerStationController;
import client.common.controllers.SupplierOrderController;
import client.common.controllers.SupplierWelcomeController;
import client.common.logic_controllers.UpdateUIController;
import message_info.*;

/**
 * this class is responsible of handling the messages recived from the server,
 * its uses switch cases to know what to do
 * 
 * @author henco
 * @version 0.9
 */
public class MessageHandlerClient {

	/**
	 * this method handles a message defending on the message's parent.
	 * 
	 * @param message that the server sends to the client
	 */
	public static void HandleMessage(Message message) {
		switch (message.getReturnedType()) {
		case LOGIN_FAILED:
			switch (message.getParent_action()) {

			case "LoginController_login_clicked":
				LoginController.instance.return_login_failed((String) message.getContent());
				break;
			}
			break;
		case LOGIN_SUCCESSFUL:
			switch (message.getParent_action()) {

			case "LoginController_login_clicked":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				LoginController.instance.get_user_firstName_AND_lastName(table);
				break;

			case "get_user_firstName_AND_lastName":
				ArrayList<ArrayList<Object>> table1 = (ArrayList<ArrayList<Object>>) message.getContent();
				LoginController.instance.return_login_success(table1);
				break;
			}

			break;
		case RETURNED_INFO:
			switch (message.getParent_action()) {
			case "CustomerNotificitionsFormController_table":
				ArrayList<ArrayList<Object>> notificationtable = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerNotificitionsFormController.instance.recivenotificationtable(notificationtable);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getratestable":
				ArrayList<ArrayList<Object>> ratestable = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.reciveratestable(ratestable);
				break;
			case "CustomerOrdersVehicleRefuelFormController_receiveSumOfSalesOf4sub":
				ArrayList<ArrayList<Object>> receivesumofsalesOf4sub = (ArrayList<ArrayList<Object>>) message
						.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receivesumofsalesOf4sub(receivesumofsalesOf4sub);
				break;
			case "CustomerNotificitionsFormController_reciveAppropiateSalesForCustomer":
				ArrayList<ArrayList<Object>> reciveappropiatesalesforCustomer = (ArrayList<ArrayList<Object>>) message
						.getContent();
				CustomerNotificitionsFormController.instance
						.reciveAppropiateSalesForCustomer(reciveappropiatesalesforCustomer);
				break;
			case "CustomerOrdersVehicleRefuelFormController_checkfuelreserveInventory":
				ArrayList<ArrayList<Object>> checkfuelreserveInventory = (ArrayList<ArrayList<Object>>) message
						.getContent();
				CustomerOrdersVehicleRefuelFormController.instance
						.receivefuelreserveInventory(checkfuelreserveInventory);
				break;
			case "CustomerOrdersHomefuelorderController_recivecustomerID":
				ArrayList<ArrayList<Object>> customerid = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersHomefuelorderController.instance.recivecustomer(customerid);
				break;
			case "CustomerOrdersVehicleRefuelFormController_recivestationname":
				ArrayList<ArrayList<Object>> stationname = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.recivestationname(stationname);
				break;
			case "CustomerNotificitionsFormController_reciveCustomerID":
				ArrayList<ArrayList<Object>> customerid2 = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerNotificitionsFormController.instance.recivecustomerid(customerid2);
				break;
			case "CustomerNotificitionsFormController_reciveSalesForCustomer":
				ArrayList<ArrayList<Object>> recivesalesforcustomer = (ArrayList<ArrayList<Object>>) message
						.getContent();
				CustomerNotificitionsFormController.instance.recivecustomersales(recivesalesforcustomer);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getSale":
				ArrayList<ArrayList<Object>> salefuel = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receivefuelsale(salefuel);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getRatesForCustomer":
				ArrayList<ArrayList<Object>> ratesfuel = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receiveratesale(ratesfuel);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getCompanySaleForCustomer":
				ArrayList<ArrayList<Object>> companysalefuel = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receivecompanyfuelsale(companysalefuel);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getstationtag":
				ArrayList<ArrayList<Object>> stationtag = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receivestationtag(stationtag);
				break;
			case "CustomerOrdersVehicleRefuelFormController_reciveCustomerID":
				ArrayList<ArrayList<Object>> customerID = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receivecustomerID(customerID);
				break;
			case "CustomerOrdersVehicleRefuelFormController_checkfuelreserveMaxquantity":
				ArrayList<ArrayList<Object>> checkfuelreserveMaxquantity = (ArrayList<ArrayList<Object>>) message
						.getContent();
				CustomerOrdersVehicleRefuelFormController.instance
						.receivefuelreserveMaxquantity(checkfuelreserveMaxquantity);
				break;
			case "CustomerOrdersHomefuelorderController_gethomefuelprice":
				ArrayList<ArrayList<Object>> homefuelprice = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersHomefuelorderController.instance.homefuelorder(homefuelprice);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getfuel":
				ArrayList<ArrayList<Object>> vehiclefuel = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersVehicleRefuelFormController.instance.receivefuel(vehiclefuel);
				break;
			case "CustomerOrdersMainController_table":
				ArrayList<ArrayList<Object>> table_orders = (ArrayList<ArrayList<Object>>) message.getContent();
				CustomerOrdersMainController.instance.tabledetails(table_orders);
				break;
			case "MarketingManagerSalesMainController_initialize":
				ArrayList<ArrayList<Object>> sale_list = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSalesMainController.instance.fill_table_sale_pattern(sale_list);
				break;

			case "MarketingManagerDiscountMainController_initialize":
				ArrayList<ArrayList<Object>> rate_list = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerDiscountMainController.instance.fill_table_dicount(rate_list);
				break;

			case "MarketingManagerReportsController_initialize":
				ArrayList<ArrayList<Object>> sale_pattern_list = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerReportsController.instance.fill_sales_ComboBox(sale_pattern_list);
				break;

			case "MarketingManagerSalesAddController_check_if_station_exist":
				ArrayList<ArrayList<Object>> sales_list = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSalesAddController.instance.getStationID(sales_list);
				break;

			case "MarketingManagerReportsController_comments_report_btn_clicked":
				ArrayList<ArrayList<Object>> comments_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_marketing_manager_comments(comments_report);
				break;

			case "MarketingManagerReportsController_periodic_characterization_report_btn_clicked":
				ArrayList<ArrayList<Object>> periodic_characterization_report = (ArrayList<ArrayList<Object>>) message
						.getContent();
				UpdateUIController.add_info_to_listview_marketing_manager_periodic_characterization(
						periodic_characterization_report);
				break;

			case "MarketingManagerNotificationController_notification_table":
				ArrayList<ArrayList<Object>> notification = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerNotificationController.instance.return_notification_table(notification);
				break;

			case "MarketingManagerNotificationController_new_notification":
				ArrayList<ArrayList<Object>> newnotification = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerNotificationController.instance.return_new_notification(newnotification);
				break;

			case "MarketingManagerSalesShowController_sale_details":
				ArrayList<ArrayList<Object>> sale_details_marketing_manager = (ArrayList<ArrayList<Object>>) message
						.getContent();
				MarketingManagerSalesShowController.instance
						.MarketingManager_return_sale_details(sale_details_marketing_manager);
				break;

			case "MarketingManagerSalesAddController_get_stations":
				ArrayList<ArrayList<Object>> StationList = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSalesAddController.instance.getStationList(StationList);
				break;

			case "MarketingManagerSalesAddController_get_station_handler":
				ArrayList<ArrayList<Object>> StationName = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSalesAddController.instance.getStationHandler(StationName);
				break;

			case "MarketingManagerNotificationController_notification_tableImpending":
				ArrayList<ArrayList<Object>> rate = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerNotificationController.instance.return_notificationImpendenig_table(rate);
				break;

			case "SaleStatisticsInformationController_count_choosen_box":
				ArrayList<ArrayList<Object>> conut_for_comboBox = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSaleStatisticsInformationController.instance
						.return_counter_comboBox(conut_for_comboBox);
				break;

			case "SaleStatisticsInformationController_general_counter":
				ArrayList<ArrayList<Object>> general_counter = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSaleStatisticsInformationController.instance.return_general_counter(general_counter);
				break;

			case "SaleStatisticsInformationController_all_comboBox":
				ArrayList<ArrayList<Object>> all_comboBox = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerSaleStatisticsInformationController.instance.return_comboBox(all_comboBox);
				break;

			case "MarketingManagerDiscountEditFuelPriceController_initialize":
				ArrayList<ArrayList<Object>> fuelName = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerDiscountEditFuelPriceController.instance.fill_fuelTypes_ComboBox(fuelName);
				break;

			case "MarketingManagerDiscountEditFuelPriceController_initialize2":
				ArrayList<ArrayList<Object>> price = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingManagerDiscountEditFuelPriceController.instance.fill_fuelprice_Txt(price);
				break;

			case "CEOReportsPageController_initialize":
				ArrayList<ArrayList<Object>> reports = (ArrayList<ArrayList<Object>>) message.getContent();
				CEOReportsPageController.instance.return_CEOReports(reports);
				break;
			case "CEONotificationsPageController_initialize":
				ArrayList<ArrayList<Object>> rates = (ArrayList<ArrayList<Object>>) message.getContent();
				CEONotificationPageController.instance.return_CEONotifications(rates);
				break;
			case "CEONotificationsPageController_notifications":
				ArrayList<ArrayList<Object>> rates1 = (ArrayList<ArrayList<Object>>) message.getContent();
				CEONotificationPageController.instance.return_CEONotificationsAlret(rates1);
				break;

			case "StationManagerStationController_setUpFuel_request":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.initializeStationManager(table);
				break;

			case "StationManagerReportsController_reserves_report_btn_clicked":
				ArrayList<ArrayList<Object>> reservse_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_station_manager_reserves(reservse_report);
				break;

			case "StationManagerReportsController_income_report_btn_clicked":
				ArrayList<ArrayList<Object>> income_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_station_manager_income(income_report);
				break;

			case "StationManagerNotificationController_initialize":
				ArrayList<ArrayList<Object>> orders = (ArrayList<ArrayList<Object>>) message.getContent();
				StationManagerNotificationController.instance.return_SupplierOrders(orders);
				break;

			case "StationManagerReportsController_purchases_report_btn_clicked":
				ArrayList<ArrayList<Object>> purchas_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_station_manager_purchases(purchas_report);
				break;

			case "StationManagerController_initialize":
				ArrayList<ArrayList<Object>> station_tag = (ArrayList<ArrayList<Object>>) message.getContent();
				StationManagerReportsController.station_tag_number = ((Integer) station_tag.get(0).get(0)).toString();
				StationManagerNotificationController.station_tag_number = ((Integer) station_tag.get(0).get(0))
						.toString();
				StationManagerController.station_tag_number = ((Integer) station_tag.get(0).get(0)).toString();
				StationManagerNotificationRejectController.station_tag_number = ((Integer) station_tag.get(0).get(0))
						.toString();
				StationManagerStationController.station_tag_number = ((Integer) station_tag.get(0).get(0)).toString();
				break;

			case "StationManagerReportsController_initialize":
				ArrayList<ArrayList<Object>> reports_s_manager = (ArrayList<ArrayList<Object>>) message.getContent();
				StationManagerReportsController.instance.returned_reports(reports_s_manager);
				break;
			case "MarketingAgentCustomersMainController_initialize_private":
				ArrayList<ArrayList<Object>> private_customers = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomersMainController.instance.fill_table_private(private_customers);
				break;
			case "MarketingAgentCustomersMainController_initialize_company":
				ArrayList<ArrayList<Object>> company_customers = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomersMainController.instance.fill_table_company(company_customers);
				break;
			// "MarketingAgentVehicleMainController_initialize_table"
			case "MarketingAgentVehicleMainController_initialize_table":
				ArrayList<ArrayList<Object>> vehicle_customer = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentVehicleMainController.instance.fill_table_vehicles(vehicle_customer);
				break;

			// "MarketingAgentSalesMainController_initialize_table"
			case "MarketingAgentSalesMainController_initialize_table":
				ArrayList<ArrayList<Object>> sale_pattern = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentSalesMainController.instance.fill_table_sale_pattern(sale_pattern);
				break;
			// "MarketingAgentCustomerAddController_get_userID"
			case "MarketingAgentCustomerAddController_get_userID":
				ArrayList<ArrayList<Object>> UserID = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerAddController.instance.getUserID(UserID);
				break;
			// "MarketingAgentCustomerPurchasePatternController_initialize_rate"
			case "MarketingAgentCustomerPurchasePatternController_initialize_rate":
				ArrayList<ArrayList<Object>> customer_subscription = (ArrayList<ArrayList<Object>>) message
						.getContent();
				MarketingAgentCustomerPurchasePatternController.instance.getCustomerSubscription(customer_subscription);
				break;
			// "MarketingAgentCustomerAddController_check_if_customer_exist"
			case "MarketingAgentCustomerAddController_check_if_customer_exist":
				ArrayList<ArrayList<Object>> customer_id = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerAddController.instance.checkIfCreditCardExist(customer_id);
				break;
			case "MarketingAgentCustomerAddController_check_if_credit_card_exist":
				ArrayList<ArrayList<Object>> customer_credit = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerAddController.instance.getCustomerID(customer_credit);
				break;
			// "MarketingAgentVehicleAddController_check_if_vehicle_exist"
			case "MarketingAgentVehicleAddController_check_if_vehicle_exist":
				ArrayList<ArrayList<Object>> customer_vehicle = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentVehicleAddController.instance.getVehicleNumber(customer_vehicle);
				break;
			// MarketingAgentSalesAddController_check_if_station_exist
			case "MarketingAgentSalesAddController_check_if_station_exist":
				ArrayList<ArrayList<Object>> station_id = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentSalesAddController.instance.getStationID(station_id);
				break;
			// "MarketingAgentSaleShowController_sale_details"
			case "MarketingAgentSaleShowController_sale_details":
				ArrayList<ArrayList<Object>> sale_details = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentSaleShowController.instance.return_sale_details(sale_details);
				break;
			// MarketingAgentCustomerPurchasePatternController_get_subscription
			case "MarketingAgentCustomerPurchasePatternController_get_subscription":
				ArrayList<ArrayList<Object>> subscription_number = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerPurchasePatternController.instance.return_subscription(subscription_number);
				break;
			// MarketingAgentCustomerPurchasePatternController_get_subscription
			case "MarketingAgentCustomerPurchasePatternController_get_subs":
				ArrayList<ArrayList<Object>> subscription = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerPurchasePatternController.instance.return_subs(subscription);
				break;
			// MarketingAgentCustomerPurchasePatternController_get_staiotns
			case "MarketingAgentCustomerPurchasePatternController_get_staiotns":
				ArrayList<ArrayList<Object>> stations = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerPurchasePatternController.instance.return_stations(stations);
				break;
			// MarketingAgentVehicleMainController_get_vehicle_rate
			case "MarketingAgentVehicleMainController_get_vehicle_rate":
				ArrayList<ArrayList<Object>> rate_delete_vehicle = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentVehicleMainController.instance.changeRateVehicle(rate_delete_vehicle);
				break;
			// MarketingAgentVehicleAddController_get_vehicle_rate
			case "MarketingAgentVehicleAddController_get_vehicle_rate":
				ArrayList<ArrayList<Object>> rate_add_vehicle = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentVehicleAddController.instance.changeRateVehicle(rate_add_vehicle);
				break;
			// MarketingAgentSalesAddController_get_stations
			case "MarketingAgentSalesAddController_get_stations":
				ArrayList<ArrayList<Object>> statoinList = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentSalesAddController.instance.getStationList(statoinList);
				break;
			// MarketingAgentNotificationController_initialize_table
			case "MarketingAgentNotificationController_initialize_table":
				ArrayList<ArrayList<Object>> notificationList = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentNotificationController.instance.getNotificationList(notificationList);
				break;
			// MarketingAgentSalesAddController_get_station_handler
			case "MarketingAgentSalesAddController_get_station_handler":
				ArrayList<ArrayList<Object>> station_handler = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentSalesAddController.instance.getStationHandler(station_handler);
				break;
////////////
			case "SupplierOrderController_search_clicked":
				ArrayList<ArrayList<Object>> specific_order = (ArrayList<ArrayList<Object>>) message.getContent();
				SupplierOrderController.instance.return_specific_order(specific_order);
				break;
			case "SupplierOrderController_initialize":
				ArrayList<ArrayList<Object>> supplier_orders = (ArrayList<ArrayList<Object>>) message.getContent();
				SupplierOrderController.instance.return_order(supplier_orders);
				break;
			case "SupplierOrderController_manager_btn_clicked":
				ArrayList<ArrayList<Object>> manager_info = (ArrayList<ArrayList<Object>>) message.getContent();
				SupplierOrderController.instance.return_manager_info(manager_info);
				break;
			case "SupplierOrderController_initialize_New_counter":
				ArrayList<ArrayList<Object>> new_order = (ArrayList<ArrayList<Object>>) message.getContent();
				SupplierOrderController.instance.return_new_order(new_order);
				break;
			case "SupplierOrderController_receive_fuel_type":
				ArrayList<ArrayList<Object>> fuel_type = (ArrayList<ArrayList<Object>>) message.getContent();
				SupplierOrderController.instance.return_fuel_type(fuel_type);
				break;
			case "SaleStatisticsInformationController_count_choosen_box_agent":
				ArrayList<ArrayList<Object>> conut_for_comboBox_agent = (ArrayList<ArrayList<Object>>) message
						.getContent();
				SaleStatisticsInformationController.instance.return_counter_comboBox(conut_for_comboBox_agent);
				break;
			case "SaleStatisticsInformationController_general_counter_agent":
				ArrayList<ArrayList<Object>> general_counter_agent = (ArrayList<ArrayList<Object>>) message
						.getContent();
				SaleStatisticsInformationController.instance.return_general_counter(general_counter_agent);
				break;
			case "SaleStatisticsInformationController_all_comboBox_agent":
				ArrayList<ArrayList<Object>> all_comboBox_agent = (ArrayList<ArrayList<Object>>) message.getContent();
				SaleStatisticsInformationController.instance.return_comboBox(all_comboBox_agent);
				break;
			}
			break;

		case RETURNED_INFO_FAILED:
			switch (message.getParent_action()) {

			case "SupplierOrderController_search_clicked":
				ArrayList<ArrayList<Object>> null_order = (ArrayList<ArrayList<Object>>) message.getContent();
				SupplierOrderController.instance.return_specific_order(null_order);

			case "MarketingManagerReportsController_comments_report_btn_clicked":
				ArrayList<ArrayList<Object>> comments_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_marketing_manager_comments(comments_report);
				break;
			case "MarketingManagerReportsController_periodic_characterization_report_btn_clicked":
				ArrayList<ArrayList<Object>> periodic_characterization_report = (ArrayList<ArrayList<Object>>) message
						.getContent();
				UpdateUIController.add_info_to_listview_marketing_manager_periodic_characterization(
						periodic_characterization_report);
				break;
			case "StationManagerReportsController_income_report_btn_clicked":
				UpdateUIController.add_info_to_listview_station_manager_income(null);
				break;
			case "StationManagerReportsController_reserves_report_btn_clicked":
				UpdateUIController.add_info_to_listview_station_manager_reserves(null);
				break;
			case "StationManagerReportsController_purchases_report_btn_clicked":
				UpdateUIController.add_info_to_listview_station_manager_purchases(null);
				break;
			case "MarketingAgentCustomersMainController_initialize_private":
				ArrayList<ArrayList<Object>> private_customers = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomersMainController.instance.fill_table_private(private_customers);
				break;
			case "MarketingAgentCustomersMainController_initialize_company":
				ArrayList<ArrayList<Object>> company_customers = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomersMainController.instance.fill_table_company(company_customers);
				break;
			case "MarketingAgentCustomerAddController_check_if_customer_exist":
				ArrayList<ArrayList<Object>> customer_id = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerAddController.instance.checkIfCreditCardExist(customer_id);
				break;
			case "MarketingAgentCustomerAddController_check_if_credit_card_exist":
				ArrayList<ArrayList<Object>> customer_credit = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentCustomerAddController.instance.getCustomerID(customer_credit);
				break;
			case "MarketingAgentVehicleAddController_check_if_vehicle_exist":
				ArrayList<ArrayList<Object>> customer_vehicle = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentVehicleAddController.instance.getVehicleNumber(customer_vehicle);
				break;
			case "MarketingAgentSalesAddController_check_if_station_exist":
				ArrayList<ArrayList<Object>> station_id = (ArrayList<ArrayList<Object>>) message.getContent();
				MarketingAgentSalesAddController.instance.getStationID(station_id);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getCompanySaleForCustomer":
				CustomerOrdersVehicleRefuelFormController.instance.receivecompanyfuelsale(null);
				break;
			case "CustomerOrdersVehicleRefuelFormController_checkfuelreserveMaxquantity":
				CustomerOrdersVehicleRefuelFormController.instance.receivefuelreserveMaxquantity(null);
				break;
			case "CustomerOrdersVehicleRefuelFormController_checkfuelreserveInventory":
				CustomerOrdersVehicleRefuelFormController.instance.receivefuelreserveInventory(null);
				break;
			case "CustomerNotificitionsFormController_table":
				CustomerNotificitionsFormController.instance.recivenotificationtable(null);
				break;
			case "CustomerNotificitionsFormController_reciveSalesForCustomer":
				CustomerNotificitionsFormController.instance.recivecustomersales(null);
				break;
			case "CustomerNotificitionsFormController_reciveAppropiateSalesForCustomer":
				CustomerNotificitionsFormController.instance.reciveAppropiateSalesForCustomer(null);
				break;
			case "CustomerOrdersMainController_table":
				CustomerOrdersMainController.instance.tabledetails(null);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getfuel":
				CustomerOrdersVehicleRefuelFormController.instance.receivefuel(null);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getSale":
				CustomerOrdersVehicleRefuelFormController.instance.receivefuelsale(null);
				break;
			case "CustomerOrdersVehicleRefuelFormController_getstationtag":
				CustomerOrdersVehicleRefuelFormController.instance.receivestationtag(null);
				break;
			}

		case UPDATE_FAILED:
			break;

		case UPDATE_SUCCESSFUL:
			switch (message.getParent_action()) {
			case "StationManagerReportsController_purchases_report_returned":
				StationManagerReportsController.instance.refresh();
				break;
			case "StationManagerReportsController_income_report_returned":
				StationManagerReportsController.instance.refresh();
				break;
			case "StationManagerReportsController_reserves_report_returned":
				StationManagerReportsController.instance.refresh();
				break;
			case "MarketingAgentVehicleMainController_delete_vehicle":
				MarketingAgentVehicleMainController.instance.checkAmountOfCars();
				break;
			// MarketingAgentVehicleAddController_add_vehicle
			case "MarketingAgentVehicleAddController_add_vehicle":
				MarketingAgentVehicleAddController.instance.checkAmountOfCars();
				break;
			case "CustomerOrdersMainController_table":
				CustomerOrdersMainController.instance.update_orders();
				break;
			case "CustomerOrdersMainController_table_updatetime":
				break;
			case "CustomerOrdersVehicleRefuelFormController_subfuelreserve":
				CustomerOrdersVehicleRefuelFormController.instance.updateOrder();
				break;
			}
			break;

		case LOGOUT_SUCCESSFUL:
			switch (message.getParent_action()) {
			// SaleStatisticsInformationController_logout_clicked
			case "SaleStatisticsInformationController_logout_clicked":
				MarketingManagerSaleStatisticsInformationController.instance.return_logout_success();
				break;
			// MarketingManagerDiscountEditFuelPriceController_logout_clicked
			case "MarketingManagerDiscountEditFuelPriceController_logout_clicked":
				MarketingManagerDiscountEditFuelPriceController.instance.return_logout_success();
				break;
			case "MarketingAgentCustomerMainController_logout_clicked":
				MarketingAgentCustomersMainController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerAddController_logout_clicked":
				MarketingAgentCustomerAddController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleMainController_logout_clicked":
				MarketingAgentVehicleMainController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleAddController_logout_clicked":
				MarketingAgentVehicleAddController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerPurchasePatternController_logout_clicked":
				MarketingAgentCustomerPurchasePatternController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerMainContoller_logout_clicked":
				MarketingAgentCustomersMainController.instance.return_logout_success();
				break;

			case "MarketingAgentMenuWelcomeController_logout_clicked":
				MarketingAgentMenuWelcomeController.instance.return_logout_success();
				break;

			case "MarketingAgentSalesMainController_logout_clicked":
				MarketingAgentSalesMainController.instance.return_logout_success();
				break;

			case "MarketingAgentSalesAddController_logout_clicked":
				MarketingAgentSalesAddController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerEditController_logout_clicked":
				MarketingAgentCustomerEditController.instance.return_logout_success();
				break;

//			case "MarketingAgentVehicleEditController_logout_clicked":
//				MarketingAgentVehicleEditController.instance.return_logout_success();
//				break;

			case "MarketingAgentNotificationController_logout_clicked":
				MarketingAgentNotificationController.instance.return_logout_success();
				break;

			case "MarketingManagerMenuWelcomeController_logout_clicked":
				MarketingManagerMenuWelcomeController.instance.return_logout_success();
				break;

			case "MarketingManagerNotificationController_logout_clicked":
				MarketingManagerNotificationController.instance.return_logout_success();
				break;

			case "MarketingManagerReportsController_logout_clicked":
				MarketingManagerReportsController.instance.return_logout_success();
				break;

			case "MarketingManagerSalesMainController_logout_clicked":
				MarketingManagerSalesMainController.instance.return_logout_success();
				break;

			case "MarketingManagerSalesAddController_logout_clicked":
				MarketingManagerSalesAddController.instance.return_logout_success();
				break;
			case "MarketingManagerDiscountMainController_logout_clicked":
				MarketingManagerDiscountMainController.instance.return_logout_success();
				break;

			case "MarketingManagerDiscountAddController_logout_clicked":
				MarketingManagerDiscountAddController.instance.return_logout_success();
				break;

			case "SupplierWelcomeController_logout_clicked":
				SupplierWelcomeController.instance.return_logout_success();

				break;
			case "SupplierOrderController_logout_clicked":
				SupplierOrderController.instance.return_logout_success();

				break;

			// MarketingAgentSaleShowController_logout_clicked
			case "MarketingAgentSaleShowController_logout_clicked":
				MarketingAgentSaleShowController.instance.return_logout_success();
				break;
/////////////////////
			case "StationManagerController_logout_clicked":
				StationManagerController.instance.return_logout_success();
				break;

			case "StationManagerNotificationController_logout_clicked":
				StationManagerNotificationController.instance.return_logout_success();
				break;

			case "StationManagerStationController_logout_clicked":
				StationManagerStationController.instance.return_logout_success();
				break;

			case "StationManagerReportsController_logout_clicked":
				StationManagerReportsController.instance.return_logout_success();
				break;

			case "StationManagerNotificationRejectController_logout_clicked":
				StationManagerNotificationRejectController.instance.return_logout_success();
				break;
			case "CEOMenuWelcomePageController_logout_clicked":
				CEOMenuWelcomePageController.instance.return_logout_success();
				break;

			case "CEOReportsPageController_logout_clicked":
				CEOReportsPageController.instance.return_logout_success();
				break;

			case "CEONotificationPageController_logout_clicked":
				CEONotificationPageController.instance.return_logout_success();
				break;
			case "CustomerOrdersMainController_logout_clicked":
				CustomerOrdersMainController.instance.return_logout_success();
				break;

			case "CustomerOrdersHomefuelorderController_logout_clicked":
				CustomerOrdersHomefuelorderController.instance.return_logout_success();
				break;
			case "CustomerNotificitionsFormController_logout_clicked":
				CustomerNotificitionsFormController.instance.return_logout_success();
				break;

			case "CustomerWelcomeController_logout_clicked":
				CustomerMenuWelcomeController.instance.return_logout_success();
				break;

			// SaleStatisticsInformationController_logout_clicked
			case "SaleStatisticsInformationController_logout_clicked_agent":
				SaleStatisticsInformationController.instance.return_logout_success();
				break;
			}
			break;

		case LOGOUT_FAILED:
			switch (message.getParent_action()) {

			}
			break;
		}
	}
}
