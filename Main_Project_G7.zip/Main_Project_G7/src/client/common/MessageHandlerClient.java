package client.common;

import java.util.ArrayList;

import client.common.controllers.CEOMenuWelcomePageController;
import client.common.controllers.CEONotificationPageController;
import client.common.controllers.CEOReportsPageController;
import client.common.controllers.CustomerMenuWelcomeController;
import client.common.controllers.CustomerNotificitionsFormController;
import client.common.controllers.CustomerOrdersHomefuelorderController;
import client.common.controllers.CustomerOrdersMainController;
import client.common.controllers.CustomerOrdersVehicleRefuelFormController;
import client.common.controllers.LoginController;
import client.common.controllers.MarketingAgentCustomerAddController;
import client.common.controllers.MarketingAgentCustomerEditController;
import client.common.controllers.MarketingAgentCustomerPurchasePatternController;
import client.common.controllers.MarketingAgentCustomersMainController;
import client.common.controllers.MarketingAgentMenuWelcomeController;
import client.common.controllers.MarketingAgentNotificationController;
import client.common.controllers.MarketingAgentSalesAddController;
import client.common.controllers.MarketingAgentSalesMainController;
import client.common.controllers.MarketingAgentVehicleAddController;
import client.common.controllers.MarketingAgentVehicleEditController;
import client.common.controllers.MarketingAgentVehicleMainController;
import client.common.controllers.MarketingManagerDiscountAddController;
import client.common.controllers.MarketingManagerDiscountMainController;
import client.common.controllers.MarketingManagerMenuWelcomeController;
import client.common.controllers.MarketingManagerNotificationController;
import client.common.controllers.MarketingManagerReportsController;
import client.common.controllers.MarketingManagerSalesAddController;
import client.common.controllers.MarketingManagerSalesMainController;
import client.common.controllers.StationManagerController;
import client.common.controllers.StationManagerNotificationController;
import client.common.controllers.StationManagerNotificationRejectController;
import client.common.controllers.StationManagerReportsController;
import client.common.controllers.StationManagerStationController;
import client.common.controllers.SupplierNotificationsController;
import client.common.controllers.SupplierNotificationsRejectController;
import client.common.controllers.SupplierOrderController;
import client.common.controllers.SupplierWelcomeController;
import client.common.logic_controllers.UpdateUIController;
import message_info.*;

//this class is responsible of handling the messages recived from the server, its uses switch cases
//to know what to do

public class MessageHandlerClient {

	public static void HandleMessage(Message message) {
		switch (message.getReturnedType()) {
		case LOGIN_FAILED:
			switch (message.getParent_action()) {
			case "LoginController_login_clicked":
				LoginController.instance.return_login_failed((String) message.getContent());
				break;
			}
			break;
		case LOGIN_SUCCESSFUL:
			switch (message.getParent_action()) {
			case "LoginController_login_clicked":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				LoginController.instance.get_user_firstName_AND_lastName(table);
				break;
			case "get_user_firstName_AND_lastName":
				ArrayList<ArrayList<Object>> table1 = (ArrayList<ArrayList<Object>>) message.getContent();
				LoginController.instance.return_login_success(table1);
				break;
			}

			break;
		case RETURNED_INFO:
			switch (message.getParent_action()) {
			case "StationManagerStationController_setUpFuel_request":
				ArrayList<ArrayList<Object>> table = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.initializeStationManager(table);
				break;

			case "StationManagerReportsController_reserves_report_btn_clicked":
				ArrayList<ArrayList<Object>> reservse_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_station_manager_reserves(reservse_report);
				break;

			case "StationManagerReportsController_income_report_btn_clicked":
				ArrayList<ArrayList<Object>> income_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_station_manager_income(income_report);
				break;
			case "CEOReportsPageController_initialize":
				ArrayList<ArrayList<Object>> reports = (ArrayList<ArrayList<Object>>) message.getContent();
				CEOReportsPageController.instance.return_CEOReports(reports);
				break;

			}
			break;

		case RETURNED_INFO_FAILED:
			switch (message.getParent_action()) {
			case "StationManagerReportsController_income_report_btn_clicked":
				ArrayList<ArrayList<Object>> income_report = (ArrayList<ArrayList<Object>>) message.getContent();
				UpdateUIController.add_info_to_listview_station_manager_income(income_report);
				break;
			}

		case UPDATE_FAILED:
			break;

		case UPDATE_SUCCESSFUL:
			break;

		case LOGOUT_SUCCESSFUL:
			switch (message.getParent_action()) {

			case "StationManagerController_logout_clicked":
				StationManagerController.instance.return_logout_success();
				break;

			case "StationManagerNotificationController_logout_clicked":
				StationManagerNotificationController.instance.return_logout_success();
				break;

			case "StationManagerStationController_logout_clicked":
				StationManagerStationController.instance.return_logout_success();
				break;

			case "StationManagerReportsController_logout_clicked":
				StationManagerReportsController.instance.return_logout_success();
				break;

			case "StationManagerNotificationRejectController_logout_clicked":
				StationManagerNotificationRejectController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerMainController_logout_clicked":
				MarketingAgentCustomersMainController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerAddController_logout_clicked":
				MarketingAgentCustomerAddController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleMainController_logout_clicked":
				MarketingAgentVehicleMainController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleAddController_logout_clicked":
				MarketingAgentVehicleAddController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerPurchasePatternController_logout_clicked":
				MarketingAgentCustomerPurchasePatternController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerMainContoller_logout_clicked":
				MarketingAgentCustomersMainController.instance.return_logout_success();
				break;

			case "MarketingAgentMenuWelcomeController_logout_clicked":
				MarketingAgentMenuWelcomeController.instance.return_logout_success();
				break;

			case "MarketingAgentSalesMainController_logout_clicked":
				MarketingAgentSalesMainController.instance.return_logout_success();
				break;

			case "MarketingAgentSalesAddController_logout_clicked":
				MarketingAgentSalesAddController.instance.return_logout_success();
				break;

			case "MarketingAgentCustomerEditController_logout_clicked":
				MarketingAgentCustomerEditController.instance.return_logout_success();
				break;

			case "MarketingAgentVehicleEditController_logout_clicked":
				MarketingAgentVehicleEditController.instance.return_logout_success();
				break;

			case "MarketingAgentNotificationController_logout_clicked":
				MarketingAgentNotificationController.instance.return_logout_success();
				break;

			case "MarketingManagerMenuWelcomeController_logout_clicked":
				MarketingManagerMenuWelcomeController.instance.return_logout_success();
				break;

			case "MarketingManagerNotificationController_logout_clicked":
				MarketingManagerNotificationController.instance.return_logout_success();
				break;

			case "MarketingManagerReportsController_logout_clicked":
				MarketingManagerReportsController.instance.return_logout_success();
				break;

			case "MarketingManagerSalesMainController_logout_clicked":
				MarketingManagerSalesMainController.instance.return_logout_success();
				break;

			case "MarketingManagerSalesAddController_logout_clicked":
				MarketingManagerSalesAddController.instance.return_logout_success();
				break;
			case "MarketingManagerDiscountMainController_logout_clicked":
				MarketingManagerDiscountMainController.instance.return_logout_success();
				break;

			case "MarketingManagerDiscountAddController_logout_clicked":
				MarketingManagerDiscountAddController.instance.return_logout_success();
				break;

			case "SupplierWelcomeController_logout_clicked":
				SupplierWelcomeController.instance.return_logout_success();

				break;
			case "SupplierOrderController_logout_clicked":
				SupplierOrderController.instance.return_logout_success();

				break;
			case "SupplierNotificationsController_logout_clicked":
				SupplierNotificationsController.instance.return_logout_success();

				break;
			case "SupplierNotificationsRejectController_logout_clicked":
				SupplierNotificationsRejectController.instance.return_logout_success();
				break;

			case "CustomerOrdersMainController_logout_clicked":
				CustomerOrdersMainController.instance.return_logout_success();
				break;

			case "CustomerOrdersHomefuelorderController_logout_clicked":
				CustomerOrdersHomefuelorderController.instance.return_logout_success();
				break;

			case "CustomerOrdersVehicleRefuelFormController_logout_clicked":
				CustomerOrdersVehicleRefuelFormController.instance.return_logout_success();
				break;
			case "CustomerNotificitionsFormController_logout_clicked":
				CustomerNotificitionsFormController.instance.return_logout_success();
				break;

			case "CustomerWelcomeController_logout_clicked":
				CustomerMenuWelcomeController.instance.return_logout_success();
				break;

			case "CEOMenuWelcomePageController_logout_clicked":
				CEOMenuWelcomePageController.instance.return_logout_success();
				break;

			case "CEOReportsPageController_logout_clicked":
				CEOReportsPageController.instance.return_logout_success();
				break;

			case "CEONotificationPageController_logout_clicked":
				CEONotificationPageController.instance.return_logout_success();
				break;
			}
			break;

		case LOGOUT_FAILED:
			switch (message.getParent_action()) {

			}
			break;
		}
	}
}
