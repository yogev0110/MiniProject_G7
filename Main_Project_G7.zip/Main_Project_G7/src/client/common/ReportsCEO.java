package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This Class is entity class For the Report Page controller
 * contain the information for the reports that the CEO get from his Station managers 
 * @author Meni
 * @version 0.99
 */

public class ReportsCEO {

	private SimpleStringProperty reportName, date, comment;
	private Integer stationNumber, reportid;

	/**
	 * constructor initialize the objects for CEO report page controller
	 * 
	 * @param reportName name of the report that the  CEO get (income report,Reserves Quantity Report,Purchases Report)
	 * @param date the date that the report has been created
	 * @param stationNumber number of the station in the report
	 * @param comment The contents of the report
	 * @param reportid to every report there is a unique id
	 */
	public ReportsCEO(String reportName, String date, Integer stationNumber, String comment, Integer reportid) {

		this.comment = new SimpleStringProperty(comment);
		this.reportName = new SimpleStringProperty(reportName);
		this.date = new SimpleStringProperty(date);
		this.stationNumber = stationNumber;
		this.reportid = reportid;
	}

	/**
	 * getter for the report name
	 * 
	 * @return reportName - the name of the report (income report,Reserves Quantity Report,Purchases Report)
	 */

	public String getReportName() {
		return reportName.getValue();
	}

	/**
	 * method that updates the value of the report name
	 * 
	 * @param reportName- (income report,Reserves Quantity Report,Purchases Report)
	 */
	public void setReportName(SimpleStringProperty reportName) {
		this.reportName = reportName;
	}

	/**
	 * getter for the report date
	 * 
	 * @return date - return the date that the report has created
	 */


	public String getDate() {
		return date.getValue();
	}

	/**
	 * method that updates the value of the report date
	 * 
	 * @param  date , the date that the report has created
	 */
	public void setDate(SimpleStringProperty date) {
		this.date = date;
	}

	/**
	 * getter for the station number
	 * 
	 * @return stationNumber - station number, to every station there is a unique number
	 */
	public Integer getStationNumber() {
		return stationNumber;
	}

	/**
	 * method that updates the value of the station number
	 * 
	 * @param stationNumber - station number, to every station there is a unique number
	 */
	public void setStationNumber(Integer stationNumber) {
		this.stationNumber = stationNumber;
	}

	/**
	 * getter for the comment
	 * 
	 * @return comment - The contents of the report
	 */
	public String getComment() {
		return comment.getValue();
	}

	/**
	 * method that updates the value of the comment that we get.
	 * 
	 * @param comment - The contents of the report
	 */
	public void setComment(SimpleStringProperty comment) {
		this.comment = comment;
	}

	/**
	 * getter for the report ID 
	 * 
	 * @return reportid - the report id
	 */
	public Integer getReportid() {
		return reportid;
	}

	/**
	 * method that updates the value of the report ID.
	 * 
	 * @param reportid - the report id
	 */
	public void setReportid(Integer reportid) {
		this.reportid = reportid;
	}

}
