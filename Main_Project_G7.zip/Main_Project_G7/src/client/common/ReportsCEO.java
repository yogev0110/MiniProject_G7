package client.common;

import javafx.beans.property.SimpleStringProperty;

public class ReportsCEO {
	
	private SimpleStringProperty reportName,date,comment;
	private Integer stationNumber;
	public ReportsCEO(String reportName,String date, Integer stationNumber,String Comment) {
		
		this.comment= new SimpleStringProperty (Comment);
		this.reportName = new SimpleStringProperty(reportName);
		this.date = new SimpleStringProperty(date);
		this.stationNumber = stationNumber;
	}
	
	public String getReportName() {
		return reportName.getValue();
	}
	public void setReportName(SimpleStringProperty reportName) {
		reportName = reportName;
	}
	public String getDate() {
		return date.getValue();
	}
	public void setDate(SimpleStringProperty date) {
		date = date;
	}
	public Integer getStationNumber() {
		return stationNumber;
	}
	public void setStationNumber(Integer stationNumber) {
		stationNumber = stationNumber;
	}

	public String getComment() {
		return comment.getValue();
	}

	public void setComment(SimpleStringProperty comment) {
		comment = comment;
	}
	
	
	
	
	

}
