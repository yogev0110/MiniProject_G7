package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class is for describe rates discounts for add to table
 * 
 * @author Yehonatan
 * @version 0.99
 */
public class MarketingManagerDiscount {
	private SimpleStringProperty rateName;
	private Float discount;
	private Integer rateType;
/**
 * Constructor for marketing manager discount
 * @param rateType the rate type form the DB
 * @param currentDiscount the disccount form the DB
 * @param rateName the rate name form the DB
 */
	public MarketingManagerDiscount(Integer rateType, Float currentDiscount, String rateName) {
		this.rateName = new SimpleStringProperty(rateName);
		this.discount = currentDiscount;
		this.rateType = rateType;
	}
	/**
	 * rate name getter
	 * 
	 * @return the name of the rate
	 */
	public String getRateName() {
		return rateName.getValue();
	}
	/**
	 * discount getter
	 * 
	 * @return the discount of the rate
	 */
	public Float getDiscount() {
		return discount;
	}
	/**
	 * rate type getter
	 * 
	 * @return the type of the rate
	 */
	public Integer getRateType() {
		return rateType;
	}

	/*public void setRateType(Integer rateType) {
		this.rateType = rateType;
	}*/

}
