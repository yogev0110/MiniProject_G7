package client.common;

import javafx.beans.property.SimpleStringProperty;
/** 
 * This Class represent a CustomerNotifications from the db that will use us 
 * to insert the propiarte customer notificatoins to the table.
 * 
 * @author Itay
 * @version 0.99
 * 
 * */
public class CustomerNotifications {
	
	private Integer customerID,notifynumber,statusNew;
	private SimpleStringProperty topic,date,description;
	
	/**
	 * Constructor of CustomerNotifications 
	 * @param customerID the customer id
	 * @param notifynumber the notification number
	 * @param topic the notification topic
	 * @param date the notification date
	 * @param description the notification description
	 * @param statusNew the notification status(read or not)
	 */
	public CustomerNotifications(Integer customerID, Integer notifynumber,
			String topic, String date, String description,Integer statusNew) {
		this.customerID = customerID;
		this.notifynumber = notifynumber;
		this.topic = new SimpleStringProperty(topic);
		this.date = new SimpleStringProperty(date);
		this.description =new SimpleStringProperty(description);
		this.statusNew=statusNew;
	}
	/**
	 * getter notification status,by comparing it to one(new) else regular notification
	 * @return notification status String
	 * 
	 */
	public String getStatusNew() {
		
		if(statusNew==1)
			return "New ";
		return "Notification";
		
	}
	/**
	 * setter notification status
	 * @param status to set the notification status
	 */
	public void setStatusNew(Integer status) {
		statusNew=status;
	}
	
	/**
	 * getter notification customerid
	 * @return notification customerid Integer
	 */
	public Integer getCustomerID() {
		return customerID;
	}
	/**
	 * getter notification number,by comparing it to (neg1) as system sale tag  else notification number
	 * @return notification number Integer
	 */
	public String getNotifynumber() {
		if(notifynumber==(-1))
			return "Sale Tag";
		return notifynumber.toString();
	}
	/**
	 * getter notification topic
	 * @return notification topic String
	 */
	public String getTopic() {
		return topic.getValue();
	}
	/**
	 * getter notification date
	 * @return notification topic String
	 */
	public String getDate() {
		return date.getValue();
	}
	/**
	 * getter notification description
	 * @return notification description String
	 */
	public String getDescription() {
		return description.getValue();
	}

	
	
	

}
