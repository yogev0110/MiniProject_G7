package client.common;

import java.util.PrimitiveIterator.OfDouble;

import com.sun.javafx.webkit.ThemeClientImpl;

import javafx.beans.property.SimpleStringProperty;

/**
 * This Class represent a HomeFuel orderes from the db that will use us to
 * insert the propiarte homefuel orderes to the table and thier status.
 * 
 * @author Itay
 * @version 0.99
 * 
 */
public class OrderHomeFuel {

	private Integer ordernum, userID;
	private Float price, quantity;
	private SimpleStringProperty orderDate, supplyDate, status, urgent, address;

	/**
	 * Constructor of home fuel order
	 * 
	 * @param ordernum   the order number
	 * @param userID     the user id
	 * @param price      the order price
	 * @param orderDate  the order date
	 * @param supplyDate the supply order date
	 * @param status     the order status, deleiverd or not
	 * @param urgent     urgent yes or no
	 * @param address    address to supply
	 * @param quantity   quantity order's fuel
	 */
	public OrderHomeFuel(Integer ordernum, Integer userID, Float price, String orderDate, String supplyDate,
			String status, String urgent, String address, Float quantity) {

		this.ordernum = ordernum;
		this.userID = userID;
		this.price = price;
		this.quantity = quantity;
		this.orderDate = new SimpleStringProperty(orderDate);
		this.supplyDate = new SimpleStringProperty(supplyDate);
		this.status = new SimpleStringProperty(status);
		this.urgent = new SimpleStringProperty(urgent);
		this.address = new SimpleStringProperty(address);
	}

	/**
	 * getter order number
	 * 
	 * @return order number Integer
	 */
	public Integer getOrdernum() {
		return ordernum;
	}

	/**
	 * getter user id
	 * 
	 * @return userid Integer
	 */
	public Integer getUserID() {
		return userID;
	}

	/**
	 * getter order price
	 * 
	 * @return userid Float
	 */
	public Float getPrice() {
		return price;
	}

	/**
	 * getter order quantity
	 * 
	 * @return quantity Float
	 */
	public Float getQuantity() {
		return quantity;
	}

	/**
	 * getter order date. it will reverse the date string from format yyyy/mm/dd to
	 * dd/mm/yyyy
	 * 
	 * @return the currect date format
	 */
	public String getOrderDate() {
		StringBuilder temp = new StringBuilder(orderDate.getValue());
		StringBuilder date = new StringBuilder();
		date.append(temp.substring(8, 10));
		date.append("/");
		date.append(temp.substring(5, 7));
		date.append("/");
		date.append(temp.substring(0, 4));
		return date.toString();
	}

	/**
	 * getter supply date. it will reverse the date string from format yyyy/mm/dd to
	 * dd/mm/yyyy
	 * 
	 * @return returns the currect date
	 */
	public String getSupplyDate() {
		StringBuilder temp = new StringBuilder(supplyDate.getValue());
		StringBuilder date = new StringBuilder();
		date.append(temp.substring(8, 10));
		date.append("/");
		date.append(temp.substring(5, 7));
		date.append("/");
		date.append(temp.substring(0, 4));
		return date.toString();
	}

	/**
	 * getter order status
	 * 
	 * @return status String
	 */
	public String getStatus() {
		return status.getValue();
	}

	/**
	 * getter order urgent status
	 * 
	 * @return urgent String
	 */
	public String getUrgent() {
		return urgent.getValue();
	}

	/**
	 * getter order address
	 * 
	 * @return address String
	 */
	public String getAddress() {
		return address.getValue();
	}

}
