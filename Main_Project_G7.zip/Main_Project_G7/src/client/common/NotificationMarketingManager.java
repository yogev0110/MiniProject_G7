package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class is for describe notifications for add to table
 * 
 * @author Yehonatan
 * @version 0.99
 */
public class NotificationMarketingManager {

	private SimpleStringProperty ratedate, ratetype, description;

	/**
	 * Constructor for marketing manager notifications
	 * @param ratetype   the rate type form DB
	 * @param ratedate    the date that it sent to the marketing manager
	 * @param description the description from the DB
	 */
	public NotificationMarketingManager(String ratetype, String ratedate, String description) {

		this.ratedate = new SimpleStringProperty(ratedate);
		this.ratetype = new SimpleStringProperty(ratetype);
		this.description = new SimpleStringProperty(description);
	}
	/**
	 * rate date getter
	 * 
	 * @return the date of the of the notification
	 */
	public String getRatedate() {
		return ratedate.getValue();
	}

//	public void setRatedate(SimpleStringProperty ratedate) {
	//	this.ratedate = ratedate;
//	}
	/**
	 * rate type getter
	 * 
	 * @return the type of the rate
	 */
	public String getRatetype() {
		return ratetype.getValue();
	}

	//public void setRatetype(SimpleStringProperty ratetype) {
		//this.ratetype = ratetype;
	//}
/**
 * description getter
 * @return the description at the notification
 */
	public String getDescription() {
		return description.getValue();
	}

	//public void setDescription(SimpleStringProperty description) {
		//this.description = description;
//	}

}
