package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import message_info.Message;
import message_info.MessageType;

public class StationManagerNotificationController extends AbstractController {

	public static StationManagerNotificationController instance; // holding an instance of this controller here

	@FXML
	private Button main_btn;

	@FXML
	private Button report_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button station_btn;

	@FXML
	private Button logout_btn;
	
	@FXML
	private Button help_btn;

	@FXML
	private Button reject_btn;

	@FXML
	private Button accept_btn;

	@FXML
	private Button delete_btn;

	@FXML
	void accept_btn_clicked(MouseEvent event) {

	}

	@FXML
	void delete_btn_clicked(MouseEvent event) {

	}
	
	@FXML
	void reject_btn_clicked(MouseEvent event) {

	}
	
	@FXML
	void help_btn_clicked(MouseEvent event) {

	}

	/*
	 * this method is responsible for handling a click in the logout button
	 */
	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "StationManagerNotificationController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	/*
	 * this method is responsible for handling a click in the manu button
	 */
	@FXML
	void main_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerForm.fxml","/client/boundry/StationManager.css");
	}
	
	/*
	 * this method is responsible for handling a click in the notification button
	 */
	@FXML
	void notification_btn_clicked(MouseEvent event) {
		
	}

	/*
	 * this method is responsible for handling a click in the report button
	 */
	@FXML
	void report_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerReportsForm.fxml",
				"/client/boundry/StationManagerReports.css");
	}

	/*
	 * this method is responsible for handling a click in the station button
	 */
	@FXML
	void station_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerStationForm.fxml",
				"/client/boundry/StationManagerStation.css");
	}
	
	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

	/*
	 * this method is the first thing that the controller does. we help to start
	 * the controller in here.
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
	}

}
