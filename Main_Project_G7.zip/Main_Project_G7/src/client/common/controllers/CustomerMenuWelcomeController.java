package client.common.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import message_info.Message;
import message_info.MessageType;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import message_info.Message;
import message_info.MessageType;
import java.net.URL;
import java.util.ResourceBundle;
import client.MainClientGUI;

public class CustomerMenuWelcomeController extends AbstractController {
	
	public static CustomerMenuWelcomeController instance;
	
	@FXML
	private Label user_fullname;
	
	@FXML
    private Button menu_btn;

    @FXML
    private Button orders_btn;

    @FXML
    private Button notifications_btn;

    @FXML
    private Button logout_btn;

    @FXML
    private Button help_btn;
    

    @FXML
    void help_btn_clicked(MouseEvent event) {

    }

    @FXML
    void logout_btn_clicked(MouseEvent event) {
    	String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "CustomerWelcomeController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);

    }

    @FXML
    void menu_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerMainForm.fxml", "/client/boundry/CustomerOrders.css");
    }

    @FXML
    void notifications_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerNotifications.fxml", "/client/boundry/CustomerOrders.css");
    }

    @FXML
    void orders_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerOrdersMainForm.fxml", "/client/boundry/CustomerOrders.css");
    }
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());

	}
	
	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}
	
	

}
