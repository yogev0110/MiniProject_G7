package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import client.common.Customer;
import client.common.logic_controllers.UserController;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class MarketingAgentCustomersMainController extends AbstractController {

	public static MarketingAgentCustomersMainController instance;
	public static boolean fl = false;
	@FXML
	private Button menu_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button customers_btn;

	@FXML
	private Button sales_btn;

	@FXML
	private Button logout_btn;

	@FXML
	private Button help_btn;

	@FXML
	private TableView<?> main_table;

	@FXML
	private TableColumn<?, ?> customerTypeColumn;

	@FXML
	private TableColumn<?, ?> fullNameCulomn;

	@FXML
	private TableColumn<?, ?> IDColumn;

	@FXML
	private TableColumn<?, ?> emailColumn;

	@FXML
	private TableColumn<?, ?> CC4DigitsColumn;

	@FXML
	private VBox menu_parent;

	@FXML
	private Button main_add_btn;

    @FXML
    private Button main_delete_btn;

	@FXML
	private Button main_select_btn;

	@FXML
	private Button edit_btn;

	@FXML
	private Button main_btn;

	@FXML
	private Button customer_info_btn;

	@FXML
	private Button vehicle_info_btn;

	@FXML
	private Button update_purchase_pattern_btn;

	@FXML
	private Button search_btn;

	@FXML
	private Label customer_name_label;

	@FXML
	private Label user_fullname;

	@FXML
	void _clicked(MouseEvent event) {

	}

	@FXML
	void customer_info_btn_clicked(MouseEvent event) {
		
		if (UserController.getCustomer()==null) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Choose customer");
			alert.setHeaderText(null);
			alert.setContentText("Please select customer");
			alert.show();
			return;
		}
			switchScenes("/client/boundry/MarketingAgentCustomerEditForm.fxml",
					"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void customers_btn_clicked(MouseEvent event) {

	}

	@FXML
	void edit_btn_clicked(MouseEvent event) {
		if (UserController.getCustomer()==null) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Choose customer");
			alert.setHeaderText(null);
			alert.setContentText("Please select customer");
			alert.show();
			return;
		}
		switchScenes("/client/boundry/MarketingAgentCustomerEditForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void help_btn_clicked(MouseEvent event) {

	}

	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "MarketingAgentCustomerMainController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	@FXML
	void main_add_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentCustomerAddForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	@FXML
	void main_btn_clicked(MouseEvent event) {

	}
	
    @FXML
    void main_delete_btn_clicked(MouseEvent event) {

    }

	@FXML
	void main_select_btn_clicked(MouseEvent event) {
		Customer customer = new Customer("Itay", "Hugi", 1234, "a@.com", 1234, 44, 10, 22, 100);//stub
		Customer customer1 = new Customer("ItayHaJonj", 1234, "a@.com", 1234, 44, 10, 22, 100);//stub
		UserController.setCustomer(customer1);
	}

	@FXML
	void menu_btn_clicked(MouseEvent event) {
		if (!fl) {
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(customers_btn.getParent());
			menu_parent.getChildren().remove(sales_btn.getParent());
			fl = true;
		} else {
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(customers_btn.getParent());
			menu_parent.getChildren().add(sales_btn.getParent());
			fl = false;
		}
	}

	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentNotificationMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void sales_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentSalesMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void search_btn_clicked(MouseEvent event) {

	}

	@FXML
	void update_purchase_pattern_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentCustomerPurchasePatternForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void vehicle_info_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentVehicleMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;

		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
		
	}

}
