package client.common.controllers;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import message_info.Message;
import message_info.MessageType;

public class CustomerOrdersHomefuelorderController extends AbstractController {
	
	private ToggleGroup toggleGroup=new ToggleGroup();
	private int flagN=0;
	private int flagY=0;
	private String QuantityInOrderDetials;
	public static CustomerOrdersHomefuelorderController instance;
	
	@FXML
	private Label user_fullname;
	
	@FXML
    private Button menu_btn;
	
	@FXML
    private TextField quantity_text;
	
    @FXML
    private Button orders_btn;

    @FXML
    private Button notifications_btn;

    @FXML
    private Button logout_btn;

    @FXML
    private Button help_btn;

    @FXML
    private Button openOrdersStatus_btn;

    @FXML
    private Button homefuelorder_btn;

    @FXML
    private Button vehiclerefuel_btn;

    @FXML
    private RadioButton yes_radiobtn;

    @FXML
    private RadioButton no_radiobtn;

    @FXML
    private DatePicker supplyDate_datepickerbtn;

    @FXML
    private Button placeAnOrder_btn;

    @FXML
    private RadioButton credit_radiobtn;

    @FXML
    private RadioButton cash_radiobtn;

    @FXML
    private Button back_btn;
    
    @FXML
    private Label quantityDetail_text;

    @FXML
    private Label urgentDetail_text;

    @FXML
    private Label supplydateDetail_text;

    @FXML
    private Label discountDetail_text;

    @FXML
    private Label payementmethodDetail_text;

    @FXML
    private Label totalDetail_text;
    
    
 

    @FXML
    void cash_radiobtn_clicked(MouseEvent event) {

    }

    @FXML
    void credit_radiobtn_clicked(MouseEvent event) {

    }

    @FXML
    void help_btn_clicked(MouseEvent event) {

    }

    @FXML
    void homefuelorder_btn_clicked(MouseEvent event) {

    }

    @FXML
    void logout_btn_clicked(MouseEvent event) {
    	String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "CustomerOrdersHomefuelorderController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);

    }
    
    public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}
    
    @FXML
    void menu_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerMainForm.fxml", "/client/boundry/CustomerOrders.css");
    }

    @FXML
    void no_radiobtn_clicked(MouseEvent event) {

    	if(no_radiobtn.isSelected()) {
    		urgentDetail_text.setText("NO");
    		yes_radiobtn.setSelected(false);
    	}else {
    		no_radiobtn.setSelected(true);
    		urgentDetail_text.setText("NO");
    		yes_radiobtn.setSelected(false);
    	}
//    	if(!no_radiobtn.isSelected()) { // if the user has enterted twice
//    		no_radiobtn.setSelected(true);
//    		flagN=1;
//    		urgentDetail_text.setText("NO");
//    		return;
//    	}
//    	else {
//    		if(flagY==1) {
//    			yes_radiobtn.setSelected(false);
//    			flagY=0;
//    		}
//    		urgentDetail_text.setText("NO");
//    		flagN=1;
//    		
//    	}
    }
    
    @FXML
    void yes_radiobtn_clicked(MouseEvent event) {
    	
    	//QuantityTemp+=quantity_text.getText();
    	//quantityDetail_text.setText(QuantityTemp+"L");
    	if(yes_radiobtn.isSelected()) {
    		urgentDetail_text.setText("YES");
    		no_radiobtn.setSelected(false);
    	}else {
    		yes_radiobtn.setSelected(true);
    		urgentDetail_text.setText("YES");
    		no_radiobtn.setSelected(false);
    	}
//    	if(!yes_radiobtn.isSelected()) { // if the user has entreated twice
//    		yes_radiobtn.setSelected(true);
//    		flagY=1;
//    		urgentDetail_text.setText("YES");
//    		return;
//    	}
//    	else {
//    		if(flagN==1) {
//    			no_radiobtn.setSelected(false);
//    			flagN=0;
//    		}
//    		urgentDetail_text.setText("YES");
//    		flagY=1;
//    		}
    	
  
    }

    @FXML
    void notifications_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerNotifications.fxml", "/client/boundry/CustomerOrders.css");

    }

    @FXML
    void openOrdersStatus_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerOrdersMainForm.fxml", "/client/boundry/CustomerOrders.css");
    }

    @FXML
    void orders_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerOrdersMainForm.fxml", "/client/boundry/CustomerOrders.css");

    }

    @FXML
    void placeAnOrder_btn_clicked(MouseEvent event) {

    }

    @FXML
    void supplyDate_datepickerbtn_clicked(MouseEvent event) {

    }

    @FXML
    void vehiclerefuel_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CustomerOrdersVehicleRefuelForm.fxml", "/client/boundry/CustomerOrders.css");

    }

    
    
    @FXML
    void quantityInOrderSetails(KeyEvent event) {
    		if(!quantity_text.getText().isEmpty())
    			quantityDetail_text.setText(quantity_text.getText()+"L");
    		else {
				quantityDetail_text.setText("");
			}
    	
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
		totalDetail_text.setVisible(false);
	}

	

}
