package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class StationManagerReportsController extends AbstractController {

	public static StationManagerReportsController instance;
	private static boolean fl = false;

	@FXML
	private VBox menu_parent;

	@FXML
	private Button main_btn;

	@FXML
	private Button report_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button station_btn;

	@FXML
	private Button logout_btn;

	@FXML
	private Button help_btn;

	@FXML
	private Label user_fullname;

	@FXML
	void help_btn_clicked(MouseEvent event) {

	}

	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "StationManagerReportsController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	@FXML
	void main_btn_clicked(MouseEvent event) {
		if (!fl) {
			menu_parent.getChildren().remove(report_btn.getParent());
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(station_btn.getParent());
			fl = true;
		} else {
			menu_parent.getChildren().add(report_btn.getParent());
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(station_btn.getParent());
			fl = false;
		}
	}

	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerNotificationForm.fxml",
				"/client/boundry/StationManagerNotification.css");
	}

	@FXML
	void report_btn_clicked(MouseEvent event) {

	}

	@FXML
	void station_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerStationForm.fxml", "/client/boundry/StationManagerStation.css");
	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
	}

}
