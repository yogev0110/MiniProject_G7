package client.common.controllers;

import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.ResourceBundle;
import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import message_info.Message;
import message_info.MessageType;

public class StationManagerReportsController extends AbstractController {

	public static StationManagerReportsController instance;
	private static boolean report_created = false;
	public static String station_tag_number;
	FileChooser fileChooser = new FileChooser();
	private static String content;

	@FXML
	private VBox menu_parent;

	@FXML
	private Button main_btn;

	@FXML
	private Button report_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button station_btn;

	@FXML
	private Button logout_btn;

	@FXML
	private Button help_btn;

	@FXML
	private Label user_fullname;

	@FXML
	private Button income_report_btn;

	@FXML
	private Button reserves_report_btn;

	@FXML
	private Button purchases_report_btn;

	@FXML
	private ListView<String> report_view;

	@FXML
	private Button download_btn;

	@FXML
	private Button send_btn;

	@FXML
	void send_btn_clicked(MouseEvent event) {
		if (report_created) {
			String timeStamp = new SimpleDateFormat("yyyy/MM/dd_HH:mm:ss").format(Calendar.getInstance().getTime());
			String quary = "INSERT INTO stations_reports (report_file, stationTag, date) VALUES (\"" + content + "\",\""
					+ station_tag_number + "\",\"" + timeStamp + "\");";
			Message message = new Message(MessageType.UPDATEINFO, "StationManagerReportsController_send_btn_clicked",
					quary);
			MainClientGUI.client.handleMessageFromClientUI(message);
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Report Sent");
			alert.setHeaderText(null);
			alert.setContentText("The Report Has Been Sent To The CEO");
			alert.show();
		}
	}

	@FXML
	void download_btn_clicked(MouseEvent event) {

		fileChooser.getExtensionFilters().add(new ExtensionFilter("text file", "*.txt"));
		File file = fileChooser.showSaveDialog(MainClientGUI.primaryStage);
		try {
			FileWriter fileWriter = new FileWriter(file);
			fileWriter.write(content);
			fileWriter.close();
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Download Failed");
			alert.setHeaderText(null);
			alert.setContentText("Downloading The Report Has Failed!");
			alert.show();
		}
	}

	@FXML
	void purchases_report_btn_clicked(MouseEvent event) {
		while (!report_view.getItems().isEmpty())
			report_view.getItems().remove(0);
		fileChooser.setInitialFileName("Purchases-Report");
		report_view.getItems().add("Purchases Report:");
	}

	@FXML
	void reserves_report_btn_clicked(MouseEvent event) {
		while (!report_view.getItems().isEmpty())
			report_view.getItems().remove(0);
		fileChooser.setInitialFileName("Reserves-Report");
		String quary = "SELECT fuel_reserves.*,fuels.fuelName FROM fuels,fuel_reserves,employees,stations WHERE employees.userID = "
				+ MainClientGUI.getUserID()
				+ " And employees.eid=stations.eid AND stations.stationTag = fuel_reserves.stationTag AND fuels.fuelType=fuel_reserves.fuelType;";
		Message message = new Message(MessageType.REQUESTINFO,
				"StationManagerReportsController_reserves_report_btn_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	public void reserves_report_returned(ArrayList<String> report) {
		for (String string : report) {
			report_view.getItems().add(string);
		}
		report_created = true;
		content = convert_ListView_to_String();
	}

	public void income_report_returned(ArrayList<String> report) {
		if (!report.isEmpty()) {
			for (String string : report) {
				report_view.getItems().add(string);
			}
			report_created = true;
			content = convert_ListView_to_String();
		} else {
			content = "No Info Found";
			report_view.getItems().add("No Info Found");
		}

	}

//	SELECT sales.fuelType,
//
//	SUM(sales.price), COUNT(sales.fuelType),sales.stationTag FROM employees, stations, sales WHERE employees.userID = 1 AND stations.eid=employees.eid AND stations.stationTag =
//
//	sales.stationTag AND (sales.date LIKE "2020/04%" OR sales.date LIKE "2020/05%" OR sales.date LIKE "2020/06%") GROUP BY fuelType,sales.stationTag

	@FXML
	void income_report_btn_clicked(MouseEvent event) {
		String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());
		String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
		while (!report_view.getItems().isEmpty())
			report_view.getItems().remove(0);
		fileChooser.setInitialFileName("Income-Report");
		Integer currentMonth = new Integer(timeStampMonth.toString());
		Integer currentYear = new Integer(timeStampYear.toString());
		currentMonth = (currentMonth / 3) * 3;
		currentMonth++;
		if (currentMonth < 10) {
			String quary = "SELECT fuels.fuelName, SUM(sales.price), COUNT(sales.fuelType), sales.stationTag FROM fuels, employees, stations, sales WHERE fuels.fuelType = sales.fuelType AND employees.userID = "
					+ MainClientGUI.getUserID()
					+ " AND employees.eid = stations.eid AND stations.stationTag = sales.stationTag AND "
					+ "(sales.date LIKE \"" + currentYear + "/0" + currentMonth + "%\" OR sales.date LIKE \""
					+ currentYear + "/0" + (currentMonth + 1) + "%\" OR " + "sales.date LIKE \"" + currentYear + "/0"
					+ (currentMonth + 2) + "%\") GROUP BY fuelName,sales.stationTag";
			Message message = new Message(MessageType.REQUESTINFO,
					"StationManagerReportsController_income_report_btn_clicked", quary);
			MainClientGUI.client.handleMessageFromClientUI(message);
		} else {
			String quary = "SELECT fuels.fuelName , SUM(sales.price), COUNT(sales.fuelType), sales.stationTag, fuels.fuelName FROM fuels, employees, stations, sales WHERE fuels.fuelType = sales.fuelType AND employees.userID = "
					+ MainClientGUI.getUserID()
					+ " AND employees.eid = stations.eid AND stations.stationTag = sales.stationTag AND "
					+ "(sales.date LIKE \"" + currentYear + "/" + currentMonth + "%\" OR sales.date LIKE \""
					+ currentYear + "/" + (currentMonth + 1) + "%\" OR " + "sales.date LIKE \"" + currentYear + "/"
					+ (currentMonth + 2) + "%\") GROUP BY fuelName,sales.stationTag";
			Message message = new Message(MessageType.REQUESTINFO,
					"StationManagerReportsController_income_report_btn_clicked", quary);
			MainClientGUI.client.handleMessageFromClientUI(message);
		}

	}

	@FXML
	void help_btn_clicked(MouseEvent event) {

	}

	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "StationManagerReportsController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	@FXML
	void main_btn_clicked(MouseEvent event) {
		if (!fl) {
			menu_parent.getChildren().remove(report_btn.getParent());
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(station_btn.getParent());
			fl = true;
		} else {
			menu_parent.getChildren().add(report_btn.getParent());
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(station_btn.getParent());
			fl = false;
		}
	}

	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerNotificationForm.fxml",
				"/client/boundry/StationManagerNotification.css");
	}

	@FXML
	void report_btn_clicked(MouseEvent event) {

	}

	@FXML
	void station_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerStationForm.fxml", "/client/boundry/StationManagerStation.css");
	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

	String convert_ListView_to_String() {
		StringBuilder page = new StringBuilder();
		for (String row : report_view.getItems()) {
			page.append(row + "\n");
		}
		return page.toString();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
		fileChooser.setInitialDirectory(new File("C:\\"));
		fileChooser.setTitle("Open Report");
	}

}
