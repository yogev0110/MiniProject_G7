package client.common.controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class StationManagerStationController extends AbstractController {

	public static StationManagerStationController instance;
	private static boolean fl = false;

	@FXML
	private VBox menu_parent;
	
	@FXML
	private Button main_btn;

	@FXML
	private Button report_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button station_btn;

	@FXML
	private Button logout_btn;

	@FXML
	private Button help_btn;

	@FXML
	private Label user_fullname;

	@FXML
	private Label motor_price;

	@FXML
	private Label motor_max;

	@FXML
	private Label motor_corrent;

	@FXML
	private ProgressBar motor_progress;

	@FXML
	private Button motor_set_thres;

	@FXML
	private Label diesel_price;

	@FXML
	private Label diesel_max;

	@FXML
	private Label diesel_corrent;

	@FXML
	private ProgressBar diesel_progress;

	@FXML
	private Button diesel_set_thres;

	@FXML
	private Label soler_price;

	@FXML
	private Label soler_max;

	@FXML
	private Label soler_corrent;

	@FXML
	private ProgressBar soler_progress;

	@FXML
	private Button soler_set_thres;

	@FXML
	private Label company_name;

	@FXML
	private Label station_tag;

	@FXML
	private Button refresh;

	@FXML
	private TextField input_for_motor;

	@FXML
	private VBox threshold_motor_vbox;

	/*
	 * this method request data of the fuel reserves in the database from the server
	 */
	private void setUpFuel_request() {
		String quary = "SELECT fuel_reserves.*,companys.companyName FROM fuel_reserves,employees,stations,companys WHERE employees.userID = "
				+ MainClientGUI.getUserID()
				+ " And employees.eid=stations.eid AND stations.stationTag = fuel_reserves.stationTag AND companys.companyTag = stations.companyTag;";
		Message message = new Message(MessageType.REQUESTINFO, "StationManagerStationController_setUpFuel_request",
				quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	/*
	 * this method is responsible in handleing the information recieved from the
	 * database
	 */
	public void setUpFuel_return(ArrayList<ArrayList<Object>> info) {

		/*
		 * display station data
		 */
		station_tag.setText("Station Tag: " + ((Integer) info.get(0).get(5)).toString());
		company_name.setText("Company: " + (String) info.get(0).get(7));
		/*
		 * display motor fuel data
		 */
		motor_price.setText("Price: " + ((Float) info.get(0).get(1)).toString());
		motor_corrent.setText("Inventory: " + ((Float) info.get(0).get(2)).toString());
		motor_max.setText("Max Amount: " + ((Float) info.get(0).get(4)).toString());
		motor_progress.setProgress(((Float) info.get(0).get(2)) / ((Float) info.get(0).get(4)));
		/*
		 * display diesel fuel data
		 */
		diesel_price.setText("Price: " + ((Float) info.get(1).get(1)).toString());
		diesel_corrent.setText("Inventory: " + ((Float) info.get(1).get(2)).toString());
		diesel_max.setText("Max Amount: " + ((Float) info.get(1).get(4)).toString());
		diesel_progress.setProgress(((Float) info.get(1).get(2)) / ((Float) info.get(1).get(4)));
		/*
		 * display soler fuel data
		 */
		soler_price.setText("Price: " + ((Float) info.get(2).get(1)).toString());
		soler_corrent.setText("Inventory: " + ((Float) info.get(2).get(2)).toString());
		soler_max.setText("Max Amount: " + ((Float) info.get(2).get(4)).toString());
		soler_progress.setProgress(((Float) info.get(2).get(2)) / ((Float) info.get(2).get(4)));
	}

	@FXML
	private void diesel_set_thres_clicked(MouseEvent event) {

	}

	@FXML
	void help_btn_clicked(MouseEvent event) {
	}

	@FXML
	void motor_set_thres_clicked(MouseEvent event) {

	}

	/*
	 * this method update the current display of the fuel reserves
	 */
	@FXML
	void refresh_clicked(MouseEvent event) {
		setUpFuel_request();
	}

	@FXML
	void soler_set_thres_clicked(MouseEvent event) {

	}

	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "StationManagerStationController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	@FXML
	void main_btn_clicked(MouseEvent event) {
		if (!fl) {
			menu_parent.getChildren().remove(report_btn.getParent());
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(station_btn.getParent());
			fl = true;
		} else {
			menu_parent.getChildren().add(report_btn.getParent());
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(station_btn.getParent());
			fl = false;
		}
	}

	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerNotificationForm.fxml",
				"/client/boundry/StationManagerNotification.css");
	}

	@FXML
	void report_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerReportsForm.fxml", "/client/boundry/StationManagerReports.css");
	}

	@FXML
	void station_btn_clicked(MouseEvent event) {

	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
		threshold_motor_vbox.getChildren().remove(input_for_motor);
		setUpFuel_request();
	}

}
