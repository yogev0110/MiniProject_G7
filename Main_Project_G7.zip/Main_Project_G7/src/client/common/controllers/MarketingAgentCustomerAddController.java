package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class MarketingAgentCustomerAddController extends AbstractController {

	public static MarketingAgentCustomerAddController instance;
	public static boolean fl = false;
	
	@FXML
	private Button menu_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button customers_btn;

	@FXML
	private Button sales_btn;

	@FXML
	private RadioButton private_radio_btn;

	@FXML
	private RadioButton company_radio_btn;

	@FXML
	private TextField company_name_txt;

	@FXML
	private TextField first_name_txt;

	@FXML
	private TextField last_name_txt;

	@FXML
	private TextField id_txt;

	@FXML
	private TextField email_txt;

	@FXML
	private TextField credit_card_number_txt;

	@FXML
	private VBox menu_parent;

	@FXML
	private ComboBox<?> month_comboBox;

	@FXML
	private ComboBox<?> year_comboBox;

	@FXML
	private TextField cvv_txt;

	@FXML
	private Button main_btn;

	@FXML
	private Button customer_info_btn;

	@FXML
	private Button vehicle_info_btn;

	@FXML
	private Button update_purchase_pattern_btn;

	@FXML
	private Button back_btn;

	@FXML
	private Button update_btn;

	@FXML
	private Button help_btn;

	@FXML
	private Button logout_btn;

	@FXML
	private Label user_fullname;

	@FXML
	void back_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentMainCustomerForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	@FXML
	void customer_info_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentCustomerEditForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void customers_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentMainCustomerForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void help_btn_clicked(MouseEvent event) {

	}

	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "MarketingAgentCustomerAddController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	@FXML
	void main_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentMainCustomerForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void menu_btn_clicked(MouseEvent event) {
		if (!fl) {
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(customers_btn.getParent());
			menu_parent.getChildren().remove(sales_btn.getParent());
			fl = true;
		} else {
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(customers_btn.getParent());
			menu_parent.getChildren().add(sales_btn.getParent());
			fl = false;
		}
	}

	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentNotificationMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void sales_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentSalesMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void update_btn_clicked(MouseEvent event) {

	}

	@FXML
	void update_purchase_pattern_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentCustomerPurchasePatternForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void vehicle_info_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentVehicleMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());

	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}
}
