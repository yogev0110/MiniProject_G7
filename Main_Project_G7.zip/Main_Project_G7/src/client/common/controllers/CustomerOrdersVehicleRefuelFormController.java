package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import message_info.Message;
import message_info.MessageType;

	public class CustomerOrdersVehicleRefuelFormController extends AbstractController {
		
		public static CustomerOrdersVehicleRefuelFormController instance;
		
		@FXML
	    private Button menu_btn;

	    @FXML
	    private Button orders_btn;

	    @FXML
	    private Button notifications_btn;

	    @FXML
	    private Button placeanorder_btn;

	    @FXML
	    private Button openOrdersStatus_btn;

	    @FXML
	    private Button homefuelorder_btn;

	    @FXML
	    private Button vehiclerefuel_btn;

	    @FXML
	    private Label quantityDetail_text;

	    @FXML
	    private Label priceperliter_text;

	    @FXML
	    private Label sale_text;

	    @FXML
	    private Label payementmethodDetail_text;

	    @FXML
	    private Label stationtagdetailtext_text;

	    @FXML
	    private Label totalDetail_text;

	    @FXML
	    private TextField vehiclenNumber_text;

	    @FXML
	    private TextField stationtag_text;

	    @FXML
	    private Button confirm_btn;

	    @FXML
	    private TextField quantity_text;

	    @FXML
	    private Button scan_btn;
	    
	    @FXML
	    private TextField quantity_text1;

	    @FXML
	    private Button logout_btn;

	    @FXML
	    private Label user_fullname;

	    @FXML
	    private Button help_btn;
	    
	    @FXML
	    void scan_btn_clicked(MouseEvent event) {

	    }

	    @FXML
	    void confirm_btn_clicked(MouseEvent event) {

	    }

	    @FXML
	    void help_btn_clicked(MouseEvent event) {

	    }

	    @FXML
	    void homefuelorder_btn_clicked(MouseEvent event) {
	    	switchScenes("/client/boundry/CustomerOrdersHomefuelorderForm.fxml", "/client/boundry/CustomerOrders.css");
	    }

	    @FXML
	    void logout_btn_clicked(MouseEvent event) {
	    	String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
			Message message = new Message(MessageType.LOGOUT, "CustomerOrdersVehicleRefuelFormController_logout_clicked", quary);
			MainClientGUI.client.handleMessageFromClientUI(message);
	    }
	    public void return_logout_success() {
			MainClientGUI.loggedIn = false;
			switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
		}

	    @FXML
	    void menu_btn_clicked(MouseEvent event) {
	    	switchScenes("/client/boundry/CustomerMainForm.fxml", "/client/boundry/CustomerOrders.css");
	    }

	    @FXML
	    void notifications_btn_clicked(MouseEvent event) {
	    	switchScenes("/client/boundry/CustomerNotifications.fxml", "/client/boundry/CustomerOrders.css");

	    }

	    @FXML
	    void openOrdersStatus_btn_clicked(MouseEvent event) {
	    	switchScenes("/client/boundry/CustomerOrdersMainForm.fxml", "/client/boundry/CustomerOrders.css");
	    }

	    @FXML
	    void orders_btn_clicked(MouseEvent event) {
	    	switchScenes("/client/boundry/CustomerOrdersMainForm.fxml", "/client/boundry/CustomerOrders.css");
	    }

	    @FXML
	    void placeanorder_btn_clicked(MouseEvent event) {

	    }

	    @FXML
	    void vehiclerefuel_btn_clicked(MouseEvent event) {

	    }

	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());

	}

}
