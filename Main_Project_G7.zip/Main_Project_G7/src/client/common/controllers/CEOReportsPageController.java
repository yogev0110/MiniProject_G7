package client.common.controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.MainClientGUI;
import client.common.ReportsCEO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class CEOReportsPageController extends AbstractController {
	
	public static CEOReportsPageController instance;

	public static boolean fl=false;
	
	@FXML
	private VBox menu_parent;

    @FXML
    private Button menu_btn;

    @FXML
    private Button notification_btn;

    @FXML
    private Button reports_btn;

    @FXML
    private Button logout_btn;

    @FXML
    private Button help_btn;

    @FXML
    private Label user_fullname;

    @FXML
    private TableView<ReportsCEO>report_table;
    
    @FXML
    private TableColumn<ReportsCEO, String> report_type_col;

    @FXML
    private TableColumn<ReportsCEO, String> date_col;

    @FXML
    private TableColumn<ReportsCEO, Integer> from_col;

    @FXML
    private TableColumn<ReportsCEO, String> comment_col;

    @FXML
    private Button open_btn;

    @FXML
    private Button delete_btn;

    @FXML
    private Button refresh_btn;

    @FXML
    void delete_btn_clicked(MouseEvent event) {

    }

    @FXML
    void help_btn_clicked(MouseEvent event) {

    }

    @FXML
    void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "CEOReportsPageController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
    }

    @FXML
    void menu_btn_clicked(MouseEvent event) {
    	if (!fl) {
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(reports_btn.getParent());
			
			fl = true;
		} else {
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(reports_btn.getParent());
			fl = false;
		}
    }

    @FXML
    void notification_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CEONotificationPageForm.fxml", "/client/boundry/CEOMenu.css");
    }

    @FXML
    void open_btn_clicked(MouseEvent event) {

    }

    @FXML
    void refresh_btn_clicked(MouseEvent event) {

    }

    @FXML
    void reports_btn_clicked(MouseEvent event) {

    }

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance=this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
		
		report_type_col.setCellValueFactory(new PropertyValueFactory<ReportsCEO, String>("reportName"));
		date_col.setCellValueFactory(new PropertyValueFactory<ReportsCEO, String>("date"));
		from_col.setCellValueFactory(new PropertyValueFactory<ReportsCEO, Integer>("stationNumber"));
		comment_col.setCellValueFactory(new PropertyValueFactory<ReportsCEO, String>("comment"));
		String quary = "SELECT * FROM stations_reports";
		Message msg = new Message(MessageType.REQUESTINFO,new String("CEOReportsPageController_initialize"), quary);
		MainClientGUI.client.handleMessageFromClientUI(msg);
		//report_table.setVisible(false);
	}
	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}
	
	public void return_CEOReports(ArrayList<ArrayList<Object>> table ) {
		ObservableList<ReportsCEO> reports = FXCollections.observableArrayList();
		
		for (ArrayList<Object> row : table) {
			reports.add(new ReportsCEO(read_untill((String)row.get(1)), (String)row.get(3),(Integer)row.get(2),(String)row.get(1)));//bvghvghvhgvhg
			
		}
		
		report_table.setItems(reports);
	//	report_table.setVisible(true);
		
	}
	public String read_untill(String reportname) {
	StringBuilder read= new StringBuilder(reportname);
	StringBuilder res=new StringBuilder() ;
		int i=0;
		while(true)
		{
			if (read.charAt(i)==':') {
				return res.toString();
			}
			else {
				res.append(read.charAt(i));
			}
			i++;
		}
		
	}	
	}
