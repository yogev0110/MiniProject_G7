package client.common.controllers;


import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class CEOMenuWelcomePageController extends AbstractController {
	
	public static CEOMenuWelcomePageController instance;
	
	public static boolean fl=false;
	
	@FXML
	private VBox menu_parent;


    @FXML
    private Button menu_btn;

    @FXML
    private Button notification_btn;

    @FXML
    private Button reports_btn;

    @FXML
    private Button logout_btn;

    @FXML
    private Button help_btn;

    @FXML
    private Label user_fullname;

    @FXML
    private Label CEO_name_label;

    @FXML
    private Label Date_time_txt;

    @FXML
    void help_btn_clicked(MouseEvent event) {

    }

    @FXML
    void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "CEOMenuWelcomePageController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
    }

    @FXML
    void menu_btn_clicked(MouseEvent event) {
    	if (!fl) {
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(reports_btn.getParent());
			
			fl = true;
		} else {
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(reports_btn.getParent());
			fl = false;
		}
    }

    @FXML
    void notification_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CEONotificationPageForm.fxml", "/client/boundry/CEOMenu.css");
    }

    @FXML
    void reports_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/CEOReportPageForm.fxml", "/client/boundry/CEOMenu.css");
    }

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());
		instance=this;
		
		
	}
	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

}
