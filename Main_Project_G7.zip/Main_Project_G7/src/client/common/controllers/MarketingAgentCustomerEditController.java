package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class MarketingAgentCustomerEditController extends AbstractController {

	public static MarketingAgentCustomerEditController instance;
	public static boolean fl = false;
	@FXML
	private Button menu_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button customers_btn;

	@FXML
	private Button sales_btn;

	@FXML
	private VBox detailsVBox;

	@FXML
	private RadioButton private_radio_btn;

	@FXML
	private RadioButton company_radio_btn;

	@FXML
	private Label companyNameLabel;

	@FXML
	private TextField companyNameTxt;

	@FXML
	private Label firstNameLabel;

	@FXML
	private TextField firstNameTxt;

	@FXML
	private Label lastNameLabel;

	@FXML
	private TextField lastNameTxt;

	@FXML
	private TextField idTxt;

	@FXML
	private TextField emailTxt;

	@FXML
	private TextField creditCardNumberTxt;

	@FXML
	private ComboBox<?> monthComboBox;

	@FXML
	private ComboBox<?> yearComboBox;

	@FXML
	private VBox menu_parent;

	@FXML
	private TextField cvvTxt;

	@FXML
	private Button main_btn;

	@FXML
	private Button customer_info_btn;

	@FXML
	private Button vehicle_info_btn;

	@FXML
	private Button update_purchase_pattern_btn;

	@FXML
	private Button back_btn;

	@FXML
	private Button update_btn;

	@FXML
	private Button logout_btn;

	@FXML
	private Button logout_btn1;

	@FXML
	private Label user_fullname;

	@FXML
	void back_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentMainCustomerForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void customer_info_btn_clicked(MouseEvent event) {

	}

	@FXML
	void customers_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentMainCustomerForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "MarketingAgentCustomerEditController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

	@FXML
	void main_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentMainCustomerForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	@FXML
	void menu_btn_clicked(MouseEvent event) {
		if (!fl) {
			menu_parent.getChildren().remove(notification_btn.getParent());
			menu_parent.getChildren().remove(customers_btn.getParent());
			menu_parent.getChildren().remove(sales_btn.getParent());
			fl = true;
		} else {
			menu_parent.getChildren().add(notification_btn.getParent());
			menu_parent.getChildren().add(customers_btn.getParent());
			menu_parent.getChildren().add(sales_btn.getParent());
			fl = false;
		}
	}

	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentNotificationMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void sales_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentSalesMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	@FXML
	void update_btn_clicked(MouseEvent event) {

	}

	@FXML
	void update_purchase_pattern_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentCustomerPurchasePatternForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");

	}

	@FXML
	void vehicle_info_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/MarketingAgentVehicleMainForm.fxml",
				"/client/boundry/MarketingAgentMainCustomer.css");
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());

	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}
}
