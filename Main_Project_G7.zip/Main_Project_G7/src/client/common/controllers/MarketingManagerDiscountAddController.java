package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import message_info.Message;
import message_info.MessageType;

public class MarketingManagerDiscountAddController extends AbstractController {
	public static MarketingManagerDiscountAddController instance;
	public static boolean fl=false;

    @FXML
    private VBox menu_parent;

    @FXML
    private Button menu_btn;

    @FXML
    private Button notification_btn;

    @FXML
    private Button reports_btn;

    @FXML
    private Button sales_btn;

    @FXML
    private Button discount_btn;

    @FXML
    private ComboBox<?> fuelTypeComboBox;

    @FXML
    private Button back_btn;

    @FXML
    private Button update_btn;

    @FXML
    private Button logout_btn;

    @FXML
    private Label user_fullname;

    @FXML
    private Button help_btn;

    @FXML
    void back_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/MarketingManagerDiscountMainForm.fxml",
				"/client/boundry/MarketingManagerMain.css");

    }
    @FXML
    void discount_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/MarketingManagerDiscountMainForm.fxml",
				"/client/boundry/MarketingManagerMain.css");


    }
    @FXML
    void help_btn_clicked(MouseEvent event) {

    }

    @FXML
	void logout_btn_clicked(MouseEvent event) {
		String quary = "UPDATE users SET connection_status = 0 WHERE userID = " + MainClientGUI.getUserID();
		Message message = new Message(MessageType.LOGOUT, "MarketingManagerDiscountAddController_logout_clicked", quary);
		MainClientGUI.client.handleMessageFromClientUI(message);
	}

    @FXML
    void menu_btn_clicked(MouseEvent event) {

    }

    @FXML
    void notification_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/MarketingManagerNotificationMainForm.fxml",
				"/client/boundry/MarketingManagerMain.css");


    }
    @FXML
    void reports_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/MarketingManagerReportsForm.fxml",
				"/client/boundry/MarketingManagerMain.css");

    }

    @FXML
    void sales_btn_clicked(MouseEvent event) {
    	switchScenes("/client/boundry/MarketingManagerSaleMainForm.fxml",
				"/client/boundry/MarketingManagerMain.css");


    }


    @FXML
    void update_btn_clicked(MouseEvent event) {

    }

    @Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		user_fullname.setText("Hello ," + MainClientGUI.getUserFirstName() + " " + MainClientGUI.getUserLastName());

	}

	public void return_logout_success() {
		MainClientGUI.loggedIn = false;
		switchScenes("/client/boundry/LoginForm.fxml", "/client/boundry/MainCss.css");
	}

}
