package client.common;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class is for describe vehicle by his userID vehicle number and fuel type
 * 
 * @author Yogev
 * @version 0.99
 */
public class Vehicle {

	private Integer userID, vehicleNumber;
	private SimpleStringProperty fuelType;

	/**
	 * Constructor for vehicle
	 * 
	 * @param userID the users id
	 * @param fuelType the fuel type
	 * @param vehicleNumber the vehicle number
	 */
	public Vehicle(Integer userID, String fuelType, Integer vehicleNumber) {
		this.userID = userID;
		this.fuelType = new SimpleStringProperty(fuelType);
		this.vehicleNumber = vehicleNumber;
	}

	/**
	 * userID getter
	 * 
	 * @return user ID
	 */
	public Integer getUserID() {
		return userID;
	}

	/**
	 * fuel type getter
	 * 
	 * @return Fuel type
	 */
	public String getFuelType() {
		return fuelType.getValue();
	}

	/**
	 * vehicle number getter
	 * 
	 * @return Vehicle number
	 */
	public Integer getVehicleNumber() {
		return vehicleNumber;
	}
}
