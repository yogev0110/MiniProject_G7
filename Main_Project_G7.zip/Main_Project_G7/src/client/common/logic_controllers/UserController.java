package client.common.logic_controllers;

import client.common.Customer;

public class UserController {

	private static Customer customer;

	public static Customer getCustomer() {
		return customer;
	}

	public static void setCustomer(Customer customer) {
		UserController.customer = customer;
	}

}
