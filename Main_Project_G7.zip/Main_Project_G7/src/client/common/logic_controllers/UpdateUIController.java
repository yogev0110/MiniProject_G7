package client.common.logic_controllers;

import java.util.ArrayList;

import client.common.controllers.StationManagerStationController;
import javafx.application.Platform;

public class UpdateUIController {

	public static void initializeStationManager(ArrayList<ArrayList<Object>> table) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerStationController.instance.setUpFuel_return(table);
			}
		});
	}
}
