package client.common.logic_controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import client.common.controllers.StationManagerReportsController;
import client.common.controllers.StationManagerStationController;
import javafx.application.Platform;

public class UpdateUIController {

	public static void initializeStationManager(ArrayList<ArrayList<Object>> table) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerStationController.instance.setUpFuel_return(table);
			}
		});
	}

	public static void add_info_to_listview_station_manager_reserves(ArrayList<ArrayList<Object>> table) {
		StationManagerReportsController.station_tag_number = ((Integer) table.get(0).get(5)).toString();
		ArrayList<String> report = new ArrayList<>();
		report.add("Reserves Report:");
		report.add("");
		report.add("Station Number : " + StationManagerReportsController.station_tag_number);
		report.add("");
		for (ArrayList<Object> arrayList : table) {
			report.add("Reserve Number: " + arrayList.get(6) + " Fuel Type: " + arrayList.get(7));
			report.add("Max Quantity In Reserve: " + arrayList.get(4) + " Minimum Threshold: "
					+ ((Float) arrayList.get(3)));
			report.add("Price For Liter: " + arrayList.get(1) + " Current Amount Of Fuel: " + arrayList.get(2));
			report.add("");

		}
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerReportsController.instance.reserves_report_returned(report);
			}
		});
	}

	public static void add_info_to_listview_station_manager_income(ArrayList<ArrayList<Object>> table) {

		ArrayList<String> report = new ArrayList<>();
		if (table != null) {
			StationManagerReportsController.station_tag_number = ((Integer) table.get(0).get(3)).toString();
			String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());
			String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
			Integer currentMonth = new Integer(timeStampMonth.toString());
			double sum = 0;
			int count = 3;
			currentMonth = (currentMonth / 3);
			currentMonth++;
			report.add("Income Report: Quarter #" + currentMonth + " Year: " + timeStampYear);
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			for (ArrayList<Object> row : table) {
				report.add("Fuel Type: " + row.get(0));
				report.add("Total Income: " + row.get(1) + " Total Purchases: " + row.get(2));
				report.add("");
				sum += (Double) row.get(1);
			}
			report.add("Monthly Avarage: " + (sum / count));
		}
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerReportsController.instance.income_report_returned(report);
			}
		});
	}
}
