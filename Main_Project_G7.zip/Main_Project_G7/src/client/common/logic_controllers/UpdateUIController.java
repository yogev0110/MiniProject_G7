package client.common.logic_controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import client.common.controllers.MarketingManagerReportsController;
import client.common.controllers.StationManagerReportsController;
import client.common.controllers.StationManagerStationController;
import javafx.application.Platform;

/**
 * a class that helps the controllers to create reports from the information
 * matrix recived from the server
 * 
 * @author henco
 * @version 0.5
 */
public class UpdateUIController {

	/**
	 * this method initialize the reserves information in a station manager
	 * "station" page
	 * 
	 * @param table with all of the relevent reserves info
	 */
	public static void initializeStationManager(ArrayList<ArrayList<Object>> table) {
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerStationController.instance.setUpFuel_return(table);
			}
		});
	}

	/**
	 * this method gets a matrix with information to create a Reserve-Report it
	 * handles all of the information in order to create an arrayList of string with
	 * rows of the report, to the controller will have an easer job to print the
	 * report
	 *
	 * @param table with report information
	 */
	public static void add_info_to_listview_station_manager_reserves(ArrayList<ArrayList<Object>> table) {
		ArrayList<String> report = new ArrayList<>();
		report.add("Reserves Report:");
		report.add("");
		report.add("Station Number : " + StationManagerReportsController.station_tag_number);
		report.add("");
		report.add("Station Name : " + table.get(0).get(8));
		report.add("");
		for (ArrayList<Object> arrayList : table) {
			report.add("Reserve Number: " + arrayList.get(6) + " Fuel Type: " + arrayList.get(7));
			report.add("Max Quantity In Reserve: " + arrayList.get(4) + " Minimum Threshold: "
					+ ((Float) arrayList.get(3)));
			report.add("Price For Liter: " + arrayList.get(1) + " Current Amount Of Fuel: " + arrayList.get(2));
			report.add("");

		}
		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				StationManagerReportsController.instance.reserves_report_returned(report);
			}
		});
	}

	/**
	 * this method gets a matrix with information to create a Income-Report it
	 * handles all of the information in order to create an arrayList of string with
	 * rows of the report, to the controller will have an easer job to print the
	 * report
	 *
	 * @param table with report information
	 */
	public static void add_info_to_listview_station_manager_income(ArrayList<ArrayList<Object>> table) {

		ArrayList<String> report = new ArrayList<>();
		if (table != null) {
			String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());
			String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
			Integer currentMonth = new Integer(timeStampMonth.toString());
			double sum = 0;
			int count = 3;
			if (currentMonth % 3 != 0) {
				currentMonth = (currentMonth / 3);
			} else {
				currentMonth = ((currentMonth / 3) - 1);
			}
			currentMonth++;
			report.add("Income Report: Quarter #" + currentMonth + " Year: " + timeStampYear);
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			report.add("Station Name : " + table.get(0).get(4));
			report.add("");
			for (ArrayList<Object> row : table) {
				report.add("Fuel Type: " + row.get(0));
				report.add("Total Income: " + String.format("%.02f", row.get(1)) + " Total Purchases: " + row.get(2));
				report.add("");
				sum += (Double) row.get(1);
			}
			report.add("Monthly Avarage: " + String.format("%.02f", (sum / count)));
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.income_report_returned(report, true);
				}
			});
		} else {
			String timeStampMonth = new SimpleDateFormat("MM").format(Calendar.getInstance().getTime());
			String timeStampYear = new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime());
			Integer currentMonth = new Integer(timeStampMonth.toString());
			if (currentMonth % 3 != 0) {
				currentMonth = (currentMonth / 3);
			} else {
				currentMonth = ((currentMonth / 3) - 1);
			}
			currentMonth++;
			report.add("Income Report: Quarter #" + currentMonth + " Year: " + timeStampYear);
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");

			report.add("Fuel Type: Motor");
			report.add("Total Income: 0.0 Total Purchases: 0");
			report.add("");
			report.add("Fuel Type: Benzin 95");
			report.add("Total Income: 0.0 Total Purchases: 0");
			report.add("");
			report.add("Fuel Type: Soler");
			report.add("Total Income: 0.0 Total Purchases: 0");
			report.add("");

			report.add("Monthly Avarage: 0.0");
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.income_report_returned(report, false);
				}
			});
		}
	}

	/**
	 * this method gets a matrix with information to create a Purchases Report it
	 * handles all of the information in order to create an arrayList of string with
	 * rows of the report, to the controller will have an easer job to print the
	 * report
	 *
	 * @param purchas_report with report information
	 */
	public static void add_info_to_listview_station_manager_purchases(ArrayList<ArrayList<Object>> purchas_report) {
		ArrayList<String> report = new ArrayList<>();
		if (purchas_report != null) {
			report.add("Purchases Report:");
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			report.add("Station Name : " + purchas_report.get(0).get(4));
			report.add("");
			for (ArrayList<Object> arrayList : purchas_report) {
				report.add("Fuel Type: " + arrayList.get(0));
				report.add("Amount Of Purchases: " + arrayList.get(3));
				report.add("Money Earned: " + String.format("%.02f", arrayList.get(1)));
				report.add("Total Amount Of Fuel Sold: " + arrayList.get(2));
				report.add("");
			}
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.purchases_report_returned(report, true);
				}
			});
		} else {
			report.add("Purchases Report:");
			report.add("");
			report.add("Station Number : " + StationManagerReportsController.station_tag_number);
			report.add("");
			report.add("Fuel Type: Motor");
			report.add("Amount Of Purchases: 0");
			report.add("Money Earned: 0");
			report.add("Total Amount Of Fuel Sold: 0");
			report.add("");
			report.add("Fuel Type: Diesel 95");
			report.add("Amount Of Purchases: 0");
			report.add("Money Earned: 0");
			report.add("Total Amount Of Fuel Sold: 0");
			report.add("");
			report.add("Fuel Type: Soler");
			report.add("Amount Of Purchases: 0");
			report.add("Money Earned: 0");
			report.add("Total Amount Of Fuel Sold: 0");
			report.add("");
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					StationManagerReportsController.instance.purchases_report_returned(report, false);
				}
			});
		}
	}
	/**
	 * this method get the details of periodic characterization report and add it to the report
	 * @param table, get the table details from DB for initialize
	 */
		public static void add_info_to_listview_marketing_manager_periodic_characterization(ArrayList<ArrayList<Object>> table) {
			ArrayList<String> report = new ArrayList<>();
			if (table != null) {
				HashMap<String, Set<String>> customerId=new HashMap<String, Set<String>>();
				report.add("Periodic Characterization Report:");
				for (ArrayList<Object> arrayList : table) {
					if(!customerId.containsKey((String)arrayList.get(0)))
					customerId.put((String)arrayList.get(0), new HashSet<String>());
				}
				for (ArrayList<Object> arrayList :table ) {
					customerId.get((String)arrayList.get(0)).add(" Amount of purchases: " + arrayList.get(1) + " Company name: " + arrayList.get(2));
				}
				for (String Id : customerId.keySet()) {
					report.add("");
					report.add("Customer ID: "+Id);
					for (String object : customerId.get(Id)) {
						report.add(object);
						
					}
					
				}
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						MarketingManagerReportsController.instance.periodic_characterization_report_returned(report);
					}
				});
			}
		}
		
		/**
		 * this method get the details of comments report for sale pattern report and add it to the report
		 * @param table, get the table details from DB for initialize
		 */
		public static void add_info_to_listview_marketing_manager_comments(ArrayList<ArrayList<Object>> table) {
			int count = 0;
			double sum = 0;
			String temp;
			ArrayList<String> report = new ArrayList<>();
			if (table != null) {
				report.add("Comments Report:");
				report.add("");
				report.add("sale patrren name : " + MarketingManagerReportsController.sale_PatrrenName);
				report.add("");
				for (ArrayList<Object> arrayList : table) {
					 temp =String.format("%.02f", arrayList.get(1));
					report.add("Customer ID: " + arrayList.get(0) + " Total spending: " + temp);
					report.add("");
					count++;
					sum += (Double) arrayList.get(1);
				}
				 temp =String.format("%.02f", sum);
				report.add("Total customers purchased in the sale : " + count);
				report.add("Total earning in the sale : " + temp);
			}
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					MarketingManagerReportsController.instance.comments_report_returned(report);

				}
			});
		}
}
