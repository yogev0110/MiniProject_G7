package client.common;

import javafx.beans.property.SimpleStringProperty;

public class UserInfo {
	
	//this class is responsible for holding information for one row in the table employee

	private SimpleStringProperty firstName, lastName, email, position, orginization;
	private Integer eid;

	public UserInfo(String first_name, String last_name, Integer eid, String email, String position,
			String orginization) {

		this.firstName = new SimpleStringProperty(first_name);
		this.lastName = new SimpleStringProperty(last_name);
		this.eid = eid;
		this.email = new SimpleStringProperty(email);
		this.position = new SimpleStringProperty(position);
		this.orginization = new SimpleStringProperty(orginization);
	}

	public Integer getEid() {
		return eid;
	}

	public String getFirstName() {
		return firstName.get();
	}

	public void setFirstName(SimpleStringProperty firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName.get();
	}

	public void setLastName(SimpleStringProperty lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email.get();
	}

	public void setEmail(SimpleStringProperty email) {
		this.email = email;
	}

	public String getPosition() {
		return position.get();
	}

	public void setPosition(SimpleStringProperty position) {
		this.position = position;
	}

	public String getOrginization() {
		return orginization.get();
	}

	public void setOrginization(SimpleStringProperty orginization) {
		this.orginization = orginization;
	}

}