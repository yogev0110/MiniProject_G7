package client.common;

/**
 * this class is for the enum of fuel. help get the corresponding value of a
 * fuel.
 * 
 * @author henco
 * @version 1.0
 */
public enum FuelType {
	/**
	 * fuel values
	 */
	Motor, Benzin, Soler, homefuel;

	/**
	 * this method get a fuel name and return the fuel name number
	 * 
	 * @param name of the fuel
	 * @return the fuels number
	 */
	public static int getFuelType(String name) {
		switch (name) {
		case "Motor":
			return 1;
		case "Benzin":
			return 2;
		case "Soler":
			return 3;
		case "homefuel":
			return 4;
		default:
			break;
		}
		try {
			throw new Exception("Fuel type error");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * this method get a fuel number and return the fuel name name
	 * 
	 * @param num number of the fuel
	 * @return the fuel name
	 */
	public static String getFuelName(Integer num) {
		switch (num) {
		case 1:
			return "Motor";
		case 2:
			return "Benzin";
		case 3:
			return "Soler";
		case 4:
			return "homefuel";
		default:
			break;
		}
		try {
			throw new Exception("Fuel type error");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Error";
	}
}
