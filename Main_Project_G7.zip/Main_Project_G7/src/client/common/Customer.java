package client.common;

import javafx.beans.property.SimpleStringProperty;

public class Customer {

	// this class is responsible for holding information for one row in the table
	// employee

	private SimpleStringProperty firstName, lastName, email, companyName;
	private Integer id, credit, userID, expMonth, expYear, cvv;
	private boolean customerType;

	public Customer(String first_name, String last_name, Integer id, String email, Integer credit, Integer userID,
			Integer expMonth, Integer expYear, Integer cvv) {

		this.firstName = new SimpleStringProperty(first_name);
		this.lastName = new SimpleStringProperty(last_name);
		this.id = id;
		this.email = new SimpleStringProperty(email);
		this.credit = credit;
		this.userID = userID;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvv = cvv;
		this.customerType = true;
	}

	public Customer(String companyName, Integer id, String email, Integer credit, Integer userID, Integer expMonth,
			Integer expYear, Integer cvv) {

		this.companyName = new SimpleStringProperty(companyName);
		this.id = id;
		this.email = new SimpleStringProperty(email);
		this.credit = credit;
		this.userID = userID;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvv = cvv;
		this.customerType = false;
	}

	public SimpleStringProperty getCompanyName() {
		return companyName;
	}

	public void setCompanyName(SimpleStringProperty companyName) {
		this.companyName = companyName;
	}

	public boolean isCustomerType() {
		return customerType;
	}

	public void setCustomerType(boolean customerType) {
		this.customerType = customerType;
	}

	public boolean getCustomerType() {
		return customerType;
	}
	public Integer getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(Integer expMonth) {
		this.expMonth = expMonth;
	}

	public Integer getExpYear() {
		return expYear;
	}

	public void setExpYear(Integer expYear) {
		this.expYear = expYear;
	}

	public Integer getCvv() {
		return cvv;
	}

	public void setCvv(Integer cvv) {
		this.cvv = cvv;
	}

	public SimpleStringProperty getFirstName() {
		return firstName;
	}

	public void setFirstName(SimpleStringProperty firstName) {
		this.firstName = firstName;
	}

	public SimpleStringProperty getLastName() {
		return lastName;
	}

	public void setLastName(SimpleStringProperty lastName) {
		this.lastName = lastName;
	}

	public SimpleStringProperty getEmail() {
		return email;
	}

	public void setEmail(SimpleStringProperty email) {
		this.email = email;
	}

	public Integer getCredit() {
		return credit;
	}

	public void setCredit(Integer credit) {
		this.credit = credit;
	}

	public Integer getId() {
		return id;
	}

	public Integer getUserID() {
		return userID;
	}

}