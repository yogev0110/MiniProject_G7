package client;

import java.io.IOException;
import java.util.Optional;
import client.common.Client;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import message_info.Message;
import message_info.MessageType;

/**
 * this class is the main class that runs the client software, is hold the
 * connection to the client side and runs the fxml aspect
 * 
 * @author henco
 * @version 0.99
 */
public class MainClientGUI extends Application {

	/**
	 * the defuel port that the client connects too.
	 */
	final public static int DEFAULT_PORT = 5555;
	/**
	 * an instance of the client
	 */
	public static Client client;
	/**
	 * if the client is running
	 */
	public static boolean is_running = false;
	/**
	 * defuel ip address for client
	 */
	private static String client_ip = "localhost";
	/**
	 * holds the corrent port
	 */
	private static int client_port = DEFAULT_PORT;
	/**
	 * holds the primary stage that the application runs on
	 */
	public static Stage primaryStage;
	/**
	 * hold the userID (clients primary key in the database)
	 */
	private static int userID;
	/**
	 * holds the users first name
	 */
	private static String userFirstName;
	/**
	 * holds the users last name
	 */
	private static String userLastName;
	/**
	 * if the client is corrently logged in to the server as a user
	 */
	public static boolean loggedIn = false;
	/**
	 * holds the corrent fxmlloader
	 */
	public static FXMLLoader loader;
	/**
	 * saves the last login date of a user
	 */
	private static String last_login_date;

	/**
	 * runs the fxml file and displays a window also connects the client to the
	 * server.
	 * 
	 * @param pStage the main stage that the application runs on
	 */
	@Override
	public void start(Stage pStage) {
		Pane pane = null;
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/client/boundry/LoginForm.fxml"));
			pane = loader.load();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		Scene s = new Scene(pane);
		s.getStylesheets().add("/client/boundry/MainCss.css");
		primaryStage = pStage;
		primaryStage.setResizable(false);
		primaryStage.setScene(s);
		primaryStage.show();
		primaryStage.setTitle("MyFuel Application");
		primaryStage.getIcons().add(new Image(this.getClass().getResource("/icons8-gas-pump-24.png").toString()));
		primaryStage.getScene().getWindow().addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.getButtonTypes().remove(ButtonType.OK);
				alert.getButtonTypes().add(ButtonType.CANCEL);
				alert.getButtonTypes().add(ButtonType.YES);
				alert.setTitle("Quit application");
				alert.setContentText(String.format("Close Client?"));
				alert.initOwner(primaryStage.getOwner());
				Optional<ButtonType> res = alert.showAndWait();

				if (res.isPresent()) {
					if (res.get().equals(ButtonType.CANCEL)) {
						event.consume();
					} else if (client != null) {
						if (loggedIn) {
							String quary = "UPDATE users SET connection_status = 0 WHERE userID = "
									+ MainClientGUI.getUserID();
							Message message = new Message(MessageType.FORCE_LOGOUT,
									"StationManagerNotificationController_logout_clicked", quary);
							MainClientGUI.client.handleMessageFromClientUI(message);
							loggedIn = false;
						}
						client.quit();
					}
				}
			}

		});
	}

	/**
	 * this method create a client side and saves it as a static instance
	 */
	public static void run_Client() {

		try {
			if (!is_running) {
				client = new Client(client_ip, client_port);
				is_running = true;
				// return true;
			} // else
				// return false;
		} catch (IOException e) {
			exit();
		}
	}

	/**
	 * main method to start the program
	 * 
	 * @param args of main class
	 */
	public static void main(String[] args) {
		launch(args);
	}

	/**
	 * returns the logged in user's id
	 * 
	 * @return users Id in the system
	 */
	public static int getUserID() {
		return userID;
	}

	/**
	 * sets the logged in user ID
	 * 
	 * @param ID the users connected id
	 */
	public static void setUserID(int ID) {
		userID = ID;
	}

	/**
	 * gets the users connected first name
	 * 
	 * @return users first name
	 */
	public static String getUserFirstName() {
		return userFirstName;
	}

	/**
	 * sets the users connected first name
	 * 
	 * @param userFirstName the user connected first name
	 */
	public static void setUserFirstName(String userFirstName) {
		MainClientGUI.userFirstName = userFirstName;
	}

	/**
	 * gets the users connected last name
	 * 
	 * @return user's last name
	 */
	public static String getUserLastName() {
		return userLastName;
	}

	/**
	 * sets the users connected last name
	 * 
	 * @param userLastName user's last name
	 */
	public static void setUserLastName(String userLastName) {
		MainClientGUI.userLastName = userLastName;
	}

	/**
	 * when exiting unexpectedly we alert the user that the connection ended
	 */
	public static void exit() {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("");
		alert.setHeaderText("Connection Failed");
		alert.setContentText("");
		alert.showAndWait();
		System.exit(0);
	}

	public static void setUserloginDate(String last_login) {
		last_login_date = last_login;
	}

	public static String getUserloginDate() {
		return last_login_date;
	}
}
