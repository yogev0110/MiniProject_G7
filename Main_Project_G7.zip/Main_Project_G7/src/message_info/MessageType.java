package message_info;

/**
 * enum class for different message types
 * 
 * @author henco
 * @version 1.0
 */
public enum MessageType {
	REQUESTINFO, UPDATEINFO, LOGIN, LOGIN_REQUEST, LOGOUT, FORCE_LOGOUT;
}
