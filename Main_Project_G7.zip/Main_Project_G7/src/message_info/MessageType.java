package message_info;

public enum MessageType {
	REQUESTINFO,UPDATEINFO,LOGIN,LOGIN_REQUEST,LOGOUT,FORCE_LOGOUT;
}
