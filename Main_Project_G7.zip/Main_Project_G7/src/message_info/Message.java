package message_info;

import java.io.Serializable;
import java.sql.ResultSet;

public class Message implements Serializable {

	// this class is responsible for holding all of the information sent beween the
	// server and the client

	private static final long serialVersionUID = 1L;
	private MessageType type;
	private ReturnMessageType returned_type;
	private String parent_action;
	private Object content;
	private String Quary;

	//this builder is for making a message for the server
	public Message(MessageType type, String parent_action, String quary) {
		this.Quary = quary;
		this.type = type;
		this.parent_action = parent_action;
	}
	
	//this builder is for making a message for the client
	public Message(ReturnMessageType returned, String parent_action, Object content) {
		this.returned_type = returned;
		this.parent_action = parent_action;
		this.content = content;
	}

	public MessageType getType() {
		return type;
	}

	public ReturnMessageType getReturnedType() {
		return returned_type;
	}

	public String getQuary() {
		return Quary;
	}

	public String getParent_action() {
		return parent_action;
	}

	public Object getContent() {
		return content;
	}

	public String toString() {
		return "Message Type: " + type.toString() + " Message Content: " + Quary.toString();
	}

}
