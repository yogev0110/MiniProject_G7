package message_info;

import java.io.Serializable;

/**
 * this class is responsible for holding all of the information sent between the
 * server and the client
 * 
 * @author henco
 * @version 1.0
 */
public class Message implements Serializable {

	/**
	 * field for Serializable class
	 */
	private static final long serialVersionUID = 1L;
	private MessageType type;
	private ReturnMessageType returned_type;
	private String parent_action;
	private Object content;
	private String Quary;

	/**
	 * this builder is for making a message for the server
	 * 
	 * @param type          message type
	 * @param parent_action with method sent the server
	 * @param quary         the quary for the server
	 */
	public Message(MessageType type, String parent_action, String quary) {
		this.Quary = quary;
		this.type = type;
		this.parent_action = parent_action;
	}

	/**
	 * this builder is for making a message for the client
	 * 
	 * @param returned      the return message type
	 * @param parent_action the method which sent the message
	 * @param content       the return info of the quary
	 */
	public Message(ReturnMessageType returned, String parent_action, Object content) {
		this.returned_type = returned;
		this.parent_action = parent_action;
		this.content = content;
	}

	/**
	 * return the message type
	 * 
	 * @return message type
	 */
	public MessageType getType() {
		return type;
	}

	/**
	 * returns the returned message type
	 * 
	 * @return returned message type
	 */
	public ReturnMessageType getReturnedType() {
		return returned_type;
	}

	/**
	 * returns the quary within the message
	 * 
	 * @return sql quary
	 */
	public String getQuary() {
		return Quary;
	}

	/**
	 * return the method that sent the message
	 * 
	 * @return string of the method
	 */
	public String getParent_action() {
		return parent_action;
	}

	/**
	 * returns the result of the quary
	 * 
	 * @return result of the quary
	 */
	public Object getContent() {
		return content;
	}

	/**
	 * simple toString
	 * 
	 * @return string representation of message
	 */
	public String toString() {
		return "Message Type: " + type.toString() + " Message Content: " + Quary.toString();
	}

}
