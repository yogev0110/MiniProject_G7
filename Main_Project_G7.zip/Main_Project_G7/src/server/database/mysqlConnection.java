package server.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import server.common.controllers.MainServerController;

/**
 * this class is our main database handler. here is the database info saved and
 * connected we execute and update our db from quarys sent by the customers
 * 
 * @author henco
 * @version 1.0
 */
public class mysqlConnection {

	/**
	 * holds a static connection to the sql database
	 */
	private static Connection connection;

	/**
	 * this method activates when we want to connect to our database, it does all of
	 * the driver connection with the jbdc. if all is correct it returns true.
	 * 
	 * @param localhost flag if we want to connect to localhost/remoteSQL server
	 * @return true if success,false if failed
	 */
	public static boolean connectToDB(boolean localhost) { // this method connects to a database
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			if (MainServerController.instance != null)
				MainServerController.instance.add_Line("Driver definition succeed");
		} catch (Exception ex) {
			/* handle the error */
			if (MainServerController.instance != null)
				MainServerController.instance.add_Line("Driver definition failed");
			return false;
		}

		try {
			if (localhost) {
				connection = DriverManager.getConnection("jdbc:mysql://localhost/KPLsaa2Lyx?serverTimezone=IST", "root",
						"207063546");
				if (MainServerController.instance != null)
					MainServerController.instance.add_Line("SQL connection succeed");

			} else {
				connection = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/KPLsaa2Lyx"
						+ "?user=KPLsaa2Lyx&password=xmR9izo873&useSSL=false&allowPublicKeyRetrieval=true");
				if (MainServerController.instance != null)
					MainServerController.instance.add_Line("SQL connection succeed");
			}
			return true;
		} catch (SQLException ex) {/* handle any errors */
			if (MainServerController.instance != null) {
				MainServerController.instance.add_Line("SQLException: " + ex.getMessage());
				MainServerController.instance.add_Line("SQLState: " + ex.getSQLState());
				MainServerController.instance.add_Line("VendorError: " + ex.getErrorCode());
			}
			return false;
		}
	}

	/**
	 * method returns the connection to the database
	 * 
	 * @return sql connection
	 */
	public static Connection getConnection() {
		try {
			if (!connection.isValid(1000)) {
				connection = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/KPLsaa2Lyx"
						+ "?user=KPLsaa2Lyx&password=xmR9izo873&useSSL=false&allowPublicKeyRetrieval=true");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	/**
	 * this method releses the connection to the database
	 */
	public static void DisconnectConnection() {
		try {
			if (!connection.isClosed())
				connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * this method execute the quary given with the statement-executeQuary method.
	 * the database returns us the result set given.
	 * 
	 * @param quary to execute
	 * @return the result set of the quary
	 */
	public static ArrayList<ArrayList<Object>> executeQuary(String quary) { // this method recives a query and returns a
																			// result set
		try {
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(quary);
			ResultSetMetaData rmd = (ResultSetMetaData) rs.getMetaData();
			int columns = rmd.getColumnCount();
			ArrayList<ArrayList<Object>> matrix = new ArrayList<>();
			int count = 0;
			while (rs.next()) {
				matrix.add(new ArrayList<Object>(columns));
				for (int i = 1; i <= columns; ++i) {
					matrix.get(count).add(rs.getObject(i));
				}
				count++;
			}
			if (count == 0) {
				rs.close();
				// connection.close();
				return null;
			} else {
				rs.close();
				// connection.close();
				return matrix;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * this method executes updates in our database
	 * 
	 * @param quary to execute
	 * @return if the update succeded or not
	 */
	public static boolean updateQuary(String quary) { // this method is for updating querying in the database
		try {
			Statement stmt = getConnection().createStatement();
			if (stmt.executeUpdate(quary) == 0) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}
