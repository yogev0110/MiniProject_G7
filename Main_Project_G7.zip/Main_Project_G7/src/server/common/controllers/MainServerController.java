package server.common.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import server.MainServerGui;
import server.common.EchoServer;
import server.common.MessageHandlerServer;
import server.common.Positions;
import server.common.controllers.logic_controllers.AnalyticSystem;
import server.common.controllers.logic_controllers.FuelReservesManager;
import server.database.mysqlConnection;

/**
 * this class is the controller class of the server window. here we will display
 * logs and user connected, in addition to choosing the server port and database
 * 
 * @author henco
 * @version 0.99
 */
public class MainServerController implements Initializable {

	/**
	 * holds an instance of the controller
	 */
	public static MainServerController instance;
	/**
	 * if the server is running
	 */
	private boolean runnig = false;
	/**
	 * what database has been choosen
	 */
	private boolean server_selected;
	/**
	 * the timer that runs every 1.5 seconds to check if there are messages to
	 * display
	 */
	private static Timer timer;
	/**
	 * queue that holds all of the messages that need to be displayed
	 */
	private static BlockingQueue<String> messageQueue;

	@FXML
	private TextArea text_display; // holds the text display

	@FXML
	private TextField text_input; // ** ** ** text input

	@FXML
	private Button enter_btn; // ** ** ** enter button

	@FXML
	private RadioButton remote_radio;

	@FXML
	private RadioButton local_radio;

	@FXML
	private TextArea users;

	@FXML
	private Button refresh_btn;

	/**
	 * if enter button has been detected, initiate the server
	 * 
	 * @param event The event that caused the method to activate
	 */
	@FXML
	void find_enter(KeyEvent event) {
		if (event.getCode() == KeyCode.ENTER) {
			Enter_clicked(null);
		}
	}

	/**
	 * if the "Enter" button in the fxml has been clicked creating a new instance of
	 * a server and saving it. letting the server to start listening connect the
	 * server to the datebase initiate the analytic and fuelReservesManager
	 * subsystem
	 * 
	 * @param event The event that caused the method to activate
	 */
	@FXML
	void Enter_clicked(MouseEvent event) {
		if (!runnig) {
			runnig = true;
			int port;
			if (text_display.getText().isEmpty())
				port = MainServerGui.DEFAULT_PORT;
			else
				port = (new Integer(text_input.getText()));
			MainServerGui.server = new EchoServer(port);
			try {
				MainServerGui.server.listen();
			} catch (IOException e) {
				add_Line("ERROR - Could not listen for clients!");
				System.err.println("Error: Server already running!");
				System.exit(0);
			}
			if (mysqlConnection.connectToDB(server_selected)) {
				AnalyticSystem.getInstance().start();
				FuelReservesManager.getInstance().start();
			}
			remote_radio.setDisable(true);
			local_radio.setDisable(true);
			refresh_clicked(null);
		}
	}

	/**
	 * this method is the first thing that the controller does. we help to start the
	 * controller in here. this method will be activated first when the fxml file is
	 * loaded
	 * 
	 * @param location  location of the controller
	 * @param resources resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
		text_display.setEditable(false);
		if (remote_radio.isSelected()) {
			server_selected = false;
		} else {
			server_selected = true;
		}
		messageQueue = new LinkedBlockingQueue<>();
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				add_logs();
			}
		};
		timer = new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 1500);
	}

	/**
	 * this method is for inserting log lines into the output of the server. it has
	 * a queue to not over load the thread.
	 */
	protected void add_logs() {
		try {
			text_display.appendText(messageQueue.take());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * this method will add messages to the output queue
	 * 
	 * @param msg we want to display
	 */
	public void add_Line(String msg) {
		try {
			messageQueue.put(msg + "\n");// text_display.appendText(msg + "\n");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

//	public void createOrdersForStation(int stationTag, int fueltype, float quantity) {
//		String suppliersQuary = "SELECT employees.eid FROM employees WHERE employees.position = 5";
//		ResultSet suppliers = mysqlConnection.executeQuary(suppliersQuary);
//		String quary;
//		String timeStamp = new SimpleDateFormat("yyyy/MM/dd_HH:mm:ss").format(Calendar.getInstance().getTime());
//		try {
//			while (suppliers.next()) {
//				quary = "INSERT INTO supplie_order(supplier_id,stationTag,fuelType,date,status,display_notification,quantity) VALUES ("
//						+ suppliers.getInt(1) + "," + stationTag + "," + fueltype + ",\"" + timeStamp
//						+ "\",\"waiting\",1," + quantity + ")";
//				MainServerController.instance.add_Line(quary);
//				// mysqlConnection.updateQuary(quary);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

	/**
	 * this method handles when the localhost radio button is pressed
	 * 
	 * @param event The event that caused the method to activate
	 */
	@FXML
	void local_radio_clicked(MouseEvent event) {
		local_radio.setSelected(true);
		server_selected = true;
		remote_radio.setSelected(false);
	}

	/**
	 * this method handles when the remoteSQL radio button is pressed
	 * 
	 * @param event The event that caused the method to activate
	 */
	@FXML
	void remote_radio_clicked(MouseEvent event) {
		remote_radio.setSelected(true);
		server_selected = false;
		local_radio.setSelected(false);
	}

	/**
	 * this method displays all of the connected users in the system
	 * 
	 * @param event The event that caused the method to activate
	 */
	@FXML
	public void refresh_clicked(MouseEvent event) {
		if (!runnig)
			return;
		users.clear();
		ArrayList<ArrayList<Object>> employees = mysqlConnection.executeQuary(
						"SELECT employees.firstName, employees.position FROM employees,users WHERE employees.userID = users.userID AND users.connection_status = 1");
		if (employees != null) {
			for (ArrayList<Object> employee : employees) {
				users.appendText(
						employee.get(0) + " - " + Positions.getPositionName((Integer) employee.get(1)) + "\n");
			}
		}
		ArrayList<ArrayList<Object>> customers = mysqlConnection.executeQuary(
						"SELECT customers.firstName FROM users,customers WHERE customers.userID = users.userID AND users.connection_status = 1 AND customers.customerType = 1");
		if (customers != null) {
			for (ArrayList<Object> customer : customers) {
				users.appendText("P.Customer - " + customer.get(0) + "\n");
			}
		}
		ArrayList<ArrayList<Object>> company_customers = mysqlConnection.executeQuary(
						"SELECT customers.companyName FROM users,customers WHERE customers.userID = users.userID AND users.connection_status = 1 AND customers.customerType = 0");
		if (company_customers != null) {
			for (ArrayList<Object> company_customer : company_customers) {
				users.appendText("C.Customer - " + company_customer.get(0) + "\n");
			}
		}
	}
}
