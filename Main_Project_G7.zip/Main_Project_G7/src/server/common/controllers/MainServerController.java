package server.common.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.MainClientGUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import server.MainServerGui;
import server.common.EchoServer;
import server.database.mysqlConnection;

public class MainServerController implements Initializable {

	public static MainServerController instance;
	private boolean runnig = false;

	@FXML
	private TextArea text_display; // holds the text display

	@FXML
	private TextField text_input; // ** ** ** text input

	@FXML
	private Button enter_btn; // ** ** ** enter button

	@FXML
	void find_enter(KeyEvent event) {
		if (event.getCode() == KeyCode.ENTER) {
			Enter_clicked(null);
		}
	}

	@FXML
	void Enter_clicked(MouseEvent event) { // when the enter button is pressed this method will activate
		if (!runnig) {
			runnig = true;
			int port;
			if (text_display.getText().isEmpty())
				port = MainServerGui.DEFAULT_PORT;
			else
				port = (new Integer(text_input.getText()));
			MainServerGui.server = new EchoServer(port); // creating a new instance of a server and saving it
			try {
				MainServerGui.server.listen(); // let the server to start listening
			} catch (IOException e) {
				add_Line("ERROR - Could not listen for clients!");
				e.printStackTrace();
			}
			mysqlConnection.connectToDB(); // finnaly, the server is connected to the datebase
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) { // this method will be activated first when the
																		// fxml file is loaded
		instance = this;
		text_display.setEditable(false);
	}

	public void add_Line(String msg) {
		text_display.appendText(msg + "\n"); // this method will display messages in the window
	}

	public void switchScenes(String fxmlFile, ActionEvent event) {

		try {
			Parent current = FXMLLoader.load(getClass().getResource(fxmlFile));
			Scene scene = new Scene(current);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
