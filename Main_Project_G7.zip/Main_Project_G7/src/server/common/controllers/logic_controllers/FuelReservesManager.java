package server.common.controllers.logic_controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import client.common.FuelType;
import server.common.controllers.MainServerController;
import server.database.mysqlConnection;

/**
 * this is a class that is a subsystem for myfue. it every so often check if
 * there is a case where the reserves are in a low state of fuel. it is
 * responsible for updateing the station managers of my fuel when there is a low
 * amount of fuel and create for them orders from all of the available suppleirs
 * 
 * @author henco
 * @version 0.99
 */
public class FuelReservesManager {

	/**
	 * holds a singleton instance of the subsystem
	 */
	private static FuelReservesManager instance = new FuelReservesManager();

	/**
	 * a timer that every so often activated
	 */
	private static Timer timer;

	/**
	 * private empty constrator
	 */
	private FuelReservesManager() {
	}

	/**
	 * returns the singleton instance of the fuelReservesManager
	 * 
	 * @return instance of fuelReservesManager
	 */
	public static FuelReservesManager getInstance() {
		return instance;
	}

	/**
	 * this method kickstarts the subsystem
	 */
	public void start() {
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				check_reserves();
			}
		};
		timer = new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 60 * 1000);
	}

	/**
	 * this method is responsible for checking if there is a need in ordering new
	 * fuel for stations.
	 */
	private void check_reserves() {
		ArrayList<ArrayList<Object>> reserves = mysqlConnection.executeQuary("SELECT * FROM fuel_reserves");
		for (ArrayList<Object> reserve : reserves) {
			// System.out.println(reserve.toString());
			Float fuelInventory = (Float) reserve.get(2);
			Float threshold = (Float) reserve.get(3);
			Float maxQuantity = (Float) reserve.get(4);
			if (threshold >= fuelInventory) {
				ArrayList<ArrayList<Object>> order = mysqlConnection
						.executeQuary("SELECT orderTag FROM supplie_order WHERE fuelType =" + reserve.get(0)
								+ " AND stationTag = " + reserve.get(5) + " AND supplie_order.status = \"Waiting\"");
				ArrayList<ArrayList<Object>> order_accepted = mysqlConnection.executeQuary(
						"SELECT orderTag FROM supplier_orders_list WHERE supplier_orders_list.gasStation = "
								+ reserve.get(5) + " AND fuelType = \""
								+ FuelType.getFuelName((new Integer(reserve.get(0).toString())))
								+ "\" AND (supplier_orders_list.status = \"Waiting\" OR supplier_orders_list.status = \"New\")");
				if (order == null && order_accepted == null) {
					ArrayList<ArrayList<Object>> suppliers = mysqlConnection
							.executeQuary("SELECT eid FROM employees WHERE position = 5");
					for (ArrayList<Object> supplier : suppliers) {
						// System.out.println(supplier.toString());
						mysqlConnection.updateQuary(
								"INSERT INTO supplie_order(supplier_id, stationTag, fuelType,date,quantity) VALUES ("
										+ supplier.get(0) + "," + reserve.get(5) + "," + reserve.get(0) + ",\""
										+ new SimpleDateFormat("yyyy/MM/dd_HH:mm:ss")
												.format(Calendar.getInstance().getTime())
										+ "\"," + (maxQuantity - fuelInventory) + ")");
						MainServerController.instance
								.add_Line("Refueling Request Made: " + FuelType.getFuelName((Integer) reserve.get(0))
										+ " For Station - " + reserve.get(5) + ". Supplier ID: " + supplier.get(0));
					}
				}
			}
		}

	}

	/**
	 * this method is for shutting down the subsystem
	 */
	public void closeSystem() {
		timer.cancel();
		// System.out.println("Fueling Manager Closing Down...");
	}
}
