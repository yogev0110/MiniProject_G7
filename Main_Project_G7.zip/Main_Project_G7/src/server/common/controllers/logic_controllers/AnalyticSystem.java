package server.common.controllers.logic_controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import server.common.controllers.MainServerController;
import server.database.mysqlConnection;

/**
 * a subsystem responsible for grading customers from 1-10
 * 
 * @author henco
 * @version 0.99
 */
public class AnalyticSystem {

	/**
	 * holds a singleton instance
	 */
	private static AnalyticSystem instance = new AnalyticSystem();

	/**
	 * the timer that runs every 24 hours to check if there is a need to update
	 * customers info
	 */
	private static Timer timer;

	/**
	 * private empty constractor
	 */
	private AnalyticSystem() {
	}

	/**
	 * returing the single instance of the analytic system
	 * 
	 * @return singleton instance
	 */
	public static AnalyticSystem getInstance() {
		return instance;
	}

	/**
	 * this method kickstarts the analytic system into action. now it will check
	 * every so often if there is a need for an update
	 */
	public void start() {
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				check_time();
			}
		};
		timer = new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 24 * 60 * 60 * 1000);
	}

	/**
	 * the method that checks, and execute the update of the analytic system. here
	 * all the magic happens. collecting data, examining it, and finnaly updateing
	 * our database
	 * 
	 */
	public void check_time() {
		String quary = "SELECT * FROM analytic_counter";
		StringBuilder last_update = null;
		last_update = new StringBuilder((String) (mysqlConnection.executeQuary(quary).get(0).get(0)));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(last_update.toString()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.add(Calendar.DAY_OF_MONTH, 7);
		String newDate = sdf.format(c.getTime());
		String timeStamp = new SimpleDateFormat("yyyy/MM/dd").format(Calendar.getInstance().getTime());
		if (timeStamp.compareTo(newDate) >= 0) {
			// System.out.println("Last update time : " + last_update);
			// System.out.println("Current Time : " + timeStamp);
			MainServerController.instance.add_Line("Analytic System Initiating Updates...");
			mysqlConnection.updateQuary("UPDATE analytic_counter SET lastUpdate = \"" + timeStamp + "\"");
			mysqlConnection.updateQuary("DELETE FROM analytic_info");
			ArrayList<ArrayList<Object>> customers = mysqlConnection.executeQuary("SELECT customers.ID FROM customers");
			// System.out.println(customers.toString());
			for (ArrayList<Object> customer : customers) {
				ArrayList<ArrayList<Object>> results = mysqlConnection
						.executeQuary("SELECT sales.quantity,sales.fuelType FROM sales WHERE sales.customerID = "
								+ customer.get(0) + " AND sales.date >=\"" + last_update + "_00:00:00\"");
				if (results != null) {
					int motor = 0, benzin = 0, soler = 0;
					double quantity = 0;
					for (ArrayList<Object> result : results) {

						// System.out.println(result.toString());

						if ((Integer) result.get(1) == 1) {
							motor++;
							quantity += (Float) result.get(0);
						}
						if ((Integer) result.get(1) == 2) {
							benzin++;
							quantity += (Float) result.get(0);
						}
						if ((Integer) result.get(1) == 3) {
							soler++;
							quantity += (Float) result.get(0);
						}
					}
					ArrayList<ArrayList<Object>> order_dates = mysqlConnection
							.executeQuary("SELECT sales.date FROM sales WHERE sales.customerID = " + customer.get(0)
									+ " AND sales.date >=\"" + last_update + "_00:00:00\"");
					// System.out.println(order_dates.toString());
					Set<String> distinct_hours = new HashSet<String>();
					for (ArrayList<Object> order : order_dates) {
						distinct_hours.add(new StringBuilder((String) order.get(0)).substring(11, 13));
					}
					String hours = distinct_hours.toString();
					// System.out.println(hours);
					int rate = 0;
					if (quantity > 1000) {
						rate += 4;
					} else {
						rate += (int) (quantity / 1000 * 4);
					}
					rate += (motor > 0 ? 1 : 0) + (benzin > 0 ? 1 : 0) + (soler > 0 ? 1 : 0);
					if (distinct_hours.isEmpty()) {
						rate++;

					} else if (distinct_hours.contains("14") || distinct_hours.contains("15")
							|| distinct_hours.contains("16") || distinct_hours.contains("17")
							|| distinct_hours.contains("18") || distinct_hours.contains("19")) {
						rate += 3;
					} else {
						rate += 2;
					}
					mysqlConnection.updateQuary(
							"INSERT INTO `analytic_info`(`customerID`, `customerType`, `fuelAmount`, `motorCustomer`, `benzinCustomer`, `solerCustomer`,`fuelingHours`) VALUES ("
									+ customer.get(0) + "," + rate + "," + quantity + "," + motor + "," + benzin + ","
									+ soler + ",\"" + hours + "\")");
				} else {
					// System.out.println("No sales");
					mysqlConnection
							.updateQuary("INSERT INTO `analytic_info`(`customerID`) VALUES (" + customer.get(0) + ")");
				}

			}
			ArrayList<ArrayList<Object>> agentsID = mysqlConnection
					.executeQuary("SELECT userID FROM employees WHERE position = 2");
			for (ArrayList<Object> id : agentsID) {
				mysqlConnection.updateQuary(
						"INSERT INTO M_A_Notification(name, date, userID, description) VALUES (\"Costumer Info Update\",\""
								+ new SimpleDateFormat("yyyy/MM/dd_HH:mm:ss").format(Calendar.getInstance().getTime())
								+ "\"," + id.get(0) + ",\"Analytic System Updated Customer Information\")");
			}

		} else {
			// System.out.println("No Need To Update");
		}
	}

	/**
	 * this method is for shutting down the analytic system
	 */
	public void closeSystem() {
		timer.cancel();
		// System.out.println("Analytic System Closing Down...");
	}
}
