package server.common;

import java.lang.reflect.Method;

import org.omg.IOP.TaggedComponentHelper;

import javafx.beans.binding.When;
import message_info.Message;
import ocsf.server.*;
import server.MainServerGui;
import server.common.controllers.MainServerController;

	//this class is the implementation of the server side.
	//here we will communicate with the clients 
public class EchoServer extends AbstractServer {

	public EchoServer(int port) {
		super(port);
	}

	//this method activates when the server recives a message
	
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		Message message = (Message) msg;		
		MessageHandlerServer.HandleMessage(message, client); 	//lets this class handle the message
		//server displays this message
		MainServerController.instance.add_Line("From: " + client.getInetAddress() + " " + msg.toString()); 
	}
	
	synchronized protected void clientDisconnected(ConnectionToClient client) {
		MainServerController.instance.add_Line("From: " + client.getInetAddress() + " Disconnected");
	}

	synchronized protected void clientException(ConnectionToClient client, Throwable exception) {
		clientDisconnected(client);
	}

	protected void serverStarted() {
		//when the server is started this method will activate
		MainServerController.instance.add_Line("Server listening for connections on port " + getPort());
	}

	protected void serverStopped() {
		//when the server is stopped this method will activate
		MainServerController.instance.add_Line("Server has stopped listening for connections.");
	}
}