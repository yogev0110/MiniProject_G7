package server.common;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import message_info.Message;
import message_info.ReturnMessageType;
import ocsf.server.ConnectionToClient;
import server.common.controllers.MainServerController;
import server.database.mysqlConnection;

/**
 * this class is responsible for all of the actions that the server recives this
 * method is dividing all of the messages to the correct action
 * 
 * @author henco
 * @version 1.0
 */
public class MessageHandlerServer {

	/**
	 * this method handles all of the messages sent by the different clients.
	 * defending on the message type, it acts accordingly. then the server sends a
	 * message back
	 * 
	 * @param message sent by the client
	 * @param client  that sent the message
	 */
	public static void HandleMessage(Message message, ConnectionToClient client) {
		switch (message.getType()) {

		case REQUESTINFO:
			ArrayList<ArrayList<Object>> return_array = null;
			return_array = mysqlConnection.executeQuary(message.getQuary());
			try {
				if (return_array != null)
					client.sendToClient(
							new Message(ReturnMessageType.RETURNED_INFO, message.getParent_action(), return_array));
				else
					client.sendToClient(
							new Message(ReturnMessageType.RETURNED_INFO_FAILED, message.getParent_action(), null));
			} catch (IOException e) {
				e.printStackTrace();
			}
			break;

		// this case is responsible for handling messages that want to update info
		case UPDATEINFO:
			boolean result = mysqlConnection.updateQuary(message.getQuary());
			if (result) {
				try {
					client.sendToClient(
							new Message(ReturnMessageType.UPDATE_SUCCESSFUL, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				try {
					client.sendToClient(new Message(ReturnMessageType.UPDATE_FAILED, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			break;

		case LOGIN:
			ArrayList<ArrayList<Object>> return_user = null;
			return_user = mysqlConnection.executeQuary(message.getQuary());
			if (return_user == null) {
				try {
					client.sendToClient(new Message(ReturnMessageType.LOGIN_FAILED, message.getParent_action(),
							new String("USERNAME OR PASSWORD INCORRECT")));
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				if ((int) return_user.get(0).get(4) == 1) {
					try {
						client.sendToClient(new Message(ReturnMessageType.LOGIN_FAILED, message.getParent_action(),
								new String("USER IS ONLINE")));
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					try {
						client.sendToClient(new Message(ReturnMessageType.LOGIN_SUCCESSFUL, message.getParent_action(),
								return_user));
						String quary = "UPDATE users SET connection_status = 1 WHERE userID = "
								+ (new Integer((int) return_user.get(0).get(2))).toString();
						mysqlConnection.updateQuary(quary);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			MainServerController.instance.refresh_clicked(null);
			break;

		case LOGIN_REQUEST:
			ArrayList<ArrayList<Object>> return_user1 = null;
			return_user1 = mysqlConnection.executeQuary(message.getQuary());
			if (return_user1 == null) {
				try {
					client.sendToClient(new Message(ReturnMessageType.LOGIN_FAILED, message.getParent_action(),
							new String("USERNAME OR PASSWORD INCORRECT")));
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				if ((int) return_user1.get(0).get(4) == 1) {
					try {
						client.sendToClient(new Message(ReturnMessageType.LOGIN_FAILED, message.getParent_action(),
								new String("USER IS ONLINE")));
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					try {
						client.sendToClient(new Message(ReturnMessageType.LOGIN_SUCCESSFUL, message.getParent_action(),
								return_user1));
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			MainServerController.instance.refresh_clicked(null);
			break;

		case LOGOUT:
			result = mysqlConnection.updateQuary(message.getQuary());
			if (result) {
				try {
					client.sendToClient(
							new Message(ReturnMessageType.LOGOUT_SUCCESSFUL, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}

			} else {
				try {
					client.sendToClient(new Message(ReturnMessageType.LOGOUT_FAILED, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			MainServerController.instance.refresh_clicked(null);
			break;

		case FORCE_LOGOUT:
			result = mysqlConnection.updateQuary(message.getQuary());
			MainServerController.instance.refresh_clicked(null);
			break;
		}
	}
}
