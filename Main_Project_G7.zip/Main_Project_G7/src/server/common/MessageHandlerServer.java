package server.common;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.sun.media.jfxmedia.events.NewFrameEvent;

import client.MainClientGUI;
import message_info.Message;
import message_info.MessageType;
import message_info.ReturnMessageType;
import ocsf.server.ConnectionToClient;
import server.MainServerGui;
import server.common.controllers.MainServerController;
import server.database.mysqlConnection;

public class MessageHandlerServer {

	// this class is responsible for all of the actions that the server recives
	// this method is dividing all of the messages to the correct action

	public static void HandleMessage(Message message, ConnectionToClient client) {
		switch (message.getType()) {

		case REQUESTINFO:
			ResultSet table = mysqlConnection.executeQuary(message.getQuary());
			ArrayList<ArrayList<Object>> return_array = null;
			try {
				return_array = resultSetToArrayList(table);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			try {
				if (return_array != null)
					client.sendToClient(
							new Message(ReturnMessageType.RETURNED_INFO, message.getParent_action(), return_array));
				else
					client.sendToClient(
							new Message(ReturnMessageType.RETURNED_INFO_FAILED, message.getParent_action(), null));
			} catch (IOException e) {
				e.printStackTrace();
			}
			break;

		// this case is responsible for handling messages that want to update info
		case UPDATEINFO:
			boolean result = mysqlConnection.updateQuary(message.getQuary());
			if (result) {
				try {
					client.sendToClient(
							new Message(ReturnMessageType.UPDATE_SUCCESSFUL, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				try {
					client.sendToClient(new Message(ReturnMessageType.UPDATE_FAILED, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			break;

		case LOGIN:
			ResultSet user = mysqlConnection.executeQuary(message.getQuary());
			ArrayList<ArrayList<Object>> return_user = null;
			try {
				return_user = resultSetToArrayList(user);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (return_user == null) {
				try {
					client.sendToClient(new Message(ReturnMessageType.LOGIN_FAILED, message.getParent_action(),
							new String("USERNAME OR PASSWORD INCORRECT")));
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				if ((int) return_user.get(0).get(4) == 1) {
					try {
						client.sendToClient(new Message(ReturnMessageType.LOGIN_FAILED, message.getParent_action(),
								new String("USER IS ONLINE")));
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					try {
						client.sendToClient(new Message(ReturnMessageType.LOGIN_SUCCESSFUL, message.getParent_action(),
								return_user));
						String quary = "UPDATE users SET connection_status = 1 WHERE userID = "
								+ (new Integer((int) return_user.get(0).get(2))).toString();
						mysqlConnection.updateQuary(quary);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			break;

		case LOGOUT:
			result = mysqlConnection.updateQuary(message.getQuary());
			if (result) {
				try {
					client.sendToClient(
							new Message(ReturnMessageType.LOGOUT_SUCCESSFUL, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}

			} else {
				try {
					client.sendToClient(new Message(ReturnMessageType.LOGOUT_FAILED, message.getParent_action(), null));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		case FORCE_LOGOUT:
			result = mysqlConnection.updateQuary(message.getQuary());
		}
	}

	// this method help to convert a resultset type into a metrix
	public static ArrayList<ArrayList<Object>> resultSetToArrayList(ResultSet rs) throws SQLException {
		ResultSetMetaData rmd = (ResultSetMetaData) rs.getMetaData();
		int columns = rmd.getColumnCount();
		ArrayList<ArrayList<Object>> matrix = new ArrayList<>();
		int count = 0;
		while (rs.next()) {
			matrix.add(new ArrayList<Object>(columns));
			for (int i = 1; i <= columns; ++i) {
				matrix.get(count).add(rs.getObject(i));
			}
			count++;
		}
		if (count == 0)
			return null;
		else
			return matrix;
	}
}
