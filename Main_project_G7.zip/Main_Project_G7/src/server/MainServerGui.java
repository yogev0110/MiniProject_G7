package server;

import java.io.IOException;
import java.util.Optional;

import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import server.common.EchoServer;
import server.database.mysqlConnection;

//this class is the main gui that runs.
//it hold the server side and can display actions within its gui

public class MainServerGui extends Application {

	final public static int DEFAULT_PORT = 5555;
	public static EchoServer server; // save an instance of the server

	@Override
	public void start(Stage primaryStage) { // runs the fxml file
		AnchorPane pane = null;
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/server/boundry/MainServerPrototypeForm.fxml"));
			pane = loader.load();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		Scene s = new Scene(pane);
		primaryStage.setScene(s);
		primaryStage.setResizable(false);
		primaryStage.show();
		primaryStage.getScene().getWindow().addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.getButtonTypes().remove(ButtonType.OK);
				alert.getButtonTypes().add(ButtonType.CANCEL);
				alert.getButtonTypes().add(ButtonType.YES);
				alert.setTitle("Quit application");
				alert.setContentText(String.format("Close Server?"));
				alert.initOwner(primaryStage.getOwner());
				Optional<ButtonType> res = alert.showAndWait();

				if (res.isPresent()) {
					if (res.get().equals(ButtonType.CANCEL)) {
						event.consume();
					} else
						try {
							if (server != null)
								server.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
			}

		});
	}

	public static void main(String[] args) {
		launch(args);
	}
}