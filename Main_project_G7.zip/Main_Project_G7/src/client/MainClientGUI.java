package client;

import java.io.IOException;
import java.util.Optional;

import client.common.Client;
import client.common.controllers.LoginController;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import message_info.Message;
import message_info.MessageType;

public class MainClientGUI extends Application {

	// this class is the main class that runs the client software, is hold the
	// connection to the client side
	// and runs the fxml aspect

	final public static int DEFAULT_PORT = 5555;
	public static Client client; // an instance of the client
	private static boolean is_running = false;
	private static String client_ip = "localhost";
	private static int client_port = DEFAULT_PORT;
	public static Stage primaryStage;
	private static int userID;
	public static boolean loggedIn = false;

	@Override
	public void start(Stage pStage) { // runs the fxml file and displays a window
		Pane pane = null;
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/client/boundry/LoginForm.fxml"));
			pane = loader.load();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		Scene s = new Scene(pane);
		s.getStylesheets().add("/client/boundry/MainCss.css");
		primaryStage = pStage;
		primaryStage.setResizable(false);
		primaryStage.setScene(s);
		primaryStage.show();
		primaryStage.getScene().getWindow().addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<Event>() {

			@Override
			public void handle(Event event) {
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.getButtonTypes().remove(ButtonType.OK);
				alert.getButtonTypes().add(ButtonType.CANCEL);
				alert.getButtonTypes().add(ButtonType.YES);
				alert.setTitle("Quit application");
				alert.setContentText(String.format("Close Client?"));
				alert.initOwner(primaryStage.getOwner());
				Optional<ButtonType> res = alert.showAndWait();

				if (res.isPresent()) {
					if (res.get().equals(ButtonType.CANCEL)) {
						event.consume();
					} else if (client != null) {
						if (loggedIn) {
							String quary = "UPDATE users SET connection_status = 0 WHERE userID = "
									+ MainClientGUI.getUserID();
							Message message = new Message(MessageType.FORCE_LOGOUT,
									"StationManagerNotificationController_logout_clicked", quary);
							MainClientGUI.client.handleMessageFromClientUI(message);
						}
						client.quit();
					}
				}
			}

		});
	}

	public static boolean run_Client() { // this method create a client side and saves it as a static instance

		try {
			if (!is_running) {
				client = new Client(client_ip, client_port);
				is_running = true;
				return true;
			} else
				return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static void main(String[] args) {
		launch(args);
	}

	public static int getUserID() {
		return userID;
	}

	public static void setUserID(int ID) {
		userID = ID;
	}
}
