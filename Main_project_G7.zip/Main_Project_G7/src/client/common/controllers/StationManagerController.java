package client.common.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

public class StationManagerController extends AbstractController {

	public static StationManagerController instance; // holding an instance of this controller here

	@FXML
	private Button main_btn;

	@FXML
	private Button report_btn;

	@FXML
	private Button notification_btn;

	@FXML
	private Button station_btn;

	@FXML
	private Button logout_btn;

	/*
	 * this method is responsible for handling a click in the logout button
	 */
	@FXML
	void logout_btn_clicked(MouseEvent event) {

	}

	/*
	 * this method is responsible for handling a click in the manu button
	 */
	@FXML
	void main_btn_clicked(MouseEvent event) {

	}
	
	/*
	 * this method is responsible for handling a click in the notification button
	 */
	@FXML
	void notification_btn_clicked(MouseEvent event) {
		switchScenes("/client/boundry/StationManagerNotificationForm.fxml","/client/boundry/StationManagerNotification.css");
	}

	/*
	 * this method is responsible for handling a click in the report button
	 */
	@FXML
	void report_btn_clicked(MouseEvent event) {

	}

	/*
	 * this method is responsible for handling a click in the station button
	 */
	@FXML
	void station_btn_clicked(MouseEvent event) {

	}

	/*
	 * this method is the first thing that the controller does. we help to start
	 * the controller in here.
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		instance = this;
	}

}
